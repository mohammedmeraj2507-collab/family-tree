import jsPDF from 'jspdf';
import { SwasthyaBimaFormData, BeneficiaryMember } from '../types';

/**
 * Generates an exact, 100% pixel-faithful A4 PDF matching the official 3-Page 
 * "MUKHYAMANTRI SWASTHYA BIMA YOJANA" Government Form as shown in the original template.
 * Page 1: Header + Member 1, 2, 3
 * Page 2: Header (compact) + Member 4, 5, 6
 * Page 3: Header + Full Address, Family Details, Signatures + LOCKED Official Blank Area
 */
export const generateSwasthyaBimaPDF = (formData: SwasthyaBimaFormData): jsPDF => {
  // A4 dimensions: 210mm x 297mm
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const marginX = 14;
  const contentWidth = pageWidth - marginX * 2; // 182mm

  // Standard column widths for the 4-column beneficiary table
  // Col 1 (Label): 50mm, Col 2 (Value): 41mm, Col 3 (Label): 50mm, Col 4 (Value): 41mm -> Total = 182mm
  const col1W = 50;
  const col2W = 41;
  const col3W = 50;
  const col4W = 41;

  const col1X = marginX;
  const col2X = col1X + col1W;
  const col3X = col2X + col2W;
  const col4X = col3X + col3W;

  const rowH = 6.2; // Table row height
  const categoryRowH = 7.5; // Slightly taller for category with small note

  // Helper to draw standard table grid box
  const drawGrid = (x: number, y: number, w: number, h: number) => {
    doc.setDrawColor(30, 30, 30);
    doc.setLineWidth(0.35);
    doc.rect(x, y, w, h);
  };

  // Helper to draw a table cell with label or value
  const drawCell = (
    x: number, 
    y: number, 
    w: number, 
    h: number, 
    text: string, 
    isBold: boolean = false, 
    fontSize: number = 8.5, 
    subText?: string,
    isCenter: boolean = false,
    textColor: [number, number, number] = [20, 20, 20]
  ) => {
    doc.setDrawColor(40, 40, 40);
    doc.setLineWidth(0.35);
    doc.rect(x, y, w, h);

    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFont('helvetica', isBold ? 'bold' : 'normal');
    doc.setFontSize(fontSize);

    if (subText) {
      // Draw main text and subtext on two lines
      doc.text(text, isCenter ? x + w / 2 : x + 2, y + 3.2, { align: isCenter ? 'center' : 'left' });
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6);
      doc.text(subText, isCenter ? x + w / 2 : x + 2, y + 6.2, { align: isCenter ? 'center' : 'left' });
    } else {
      // Single line vertical center
      const textY = y + (h / 2) + (fontSize * 0.35 / 2);
      doc.text(text, isCenter ? x + w / 2 : x + 2.5, textY, { 
        align: isCenter ? 'center' : 'left',
        maxWidth: w - 4
      });
    }
  };

  // Function to render a single Member Block (exact replica of uploaded image)
  const drawMemberBlock = (startY: number, memberIndex: number, member?: BeneficiaryMember) => {
    const m = member || {
      id: memberIndex,
      memberLabel: `Member ${memberIndex}`,
      aadharNo: '',
      applicantName: '',
      rationCardNo: '',
      category: '',
      aadharLinkedMobile: '',
      gender: '',
      dob: '',
      panNumber: '',
      epicNumber: '',
      acNumber: '',
      partNumber: '',
      serialNumber: '',
    };

    let curY = startY;

    // 1. Header Label outside table (Left aligned, Bold uppercase)
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 15, 15);
    doc.text(`BASIC BENEFICIARY DETAILS (Member ${memberIndex})`, marginX, curY);
    curY += 2.2;

    // 2. Row 1: Aadhar No | Applicant Name
    drawCell(col1X, curY, col1W, rowH, 'Aadhar No', true, 8);
    drawCell(col2X, curY, col2W, rowH, m.aadharNo || '', false, 8.5, undefined, false, [0, 0, 140]);
    drawCell(col3X, curY, col3W, rowH, 'Applicant Name', true, 8);
    drawCell(col4X, curY, col4W, rowH, m.applicantName || '', true, 8.5, undefined, false, [0, 0, 0]);
    curY += rowH;

    // 3. Row 2: Ration Card No. | Category
    drawCell(col1X, curY, col1W, categoryRowH, 'Ration Card No.', true, 8);
    drawCell(col2X, curY, col2W, categoryRowH, m.rationCardNo || '', false, 8.5);
    drawCell(col3X, curY, col3W, categoryRowH, 'Category', true, 8, '(AAY/SPHH/PHH/RKSY-1/RKSY-2/GEN)');
    drawCell(col4X, curY, col4W, categoryRowH, m.category || '', true, 8.5);
    curY += categoryRowH;

    // 4. Row 3: Aadhar Linked Mobile | Gender (M/F/O)
    drawCell(col1X, curY, col1W, rowH, 'Aadhar Linked Mobile', true, 8);
    drawCell(col2X, curY, col2W, rowH, m.aadharLinkedMobile || '', false, 8.5);
    drawCell(col3X, curY, col3W, rowH, 'Gender (M/F/O)', true, 8);
    drawCell(col4X, curY, col4W, rowH, m.gender || '', false, 8.5);
    curY += rowH;

    // 5. Row 4: Date of Birth | PAN Number
    drawCell(col1X, curY, col1W, rowH, 'Date of Birth', true, 8);
    drawCell(col2X, curY, col2W, rowH, m.dob || '', false, 8.5);
    drawCell(col3X, curY, col3W, rowH, 'PAN Number', true, 8);
    drawCell(col4X, curY, col4W, rowH, m.panNumber || '', false, 8.5);
    curY += rowH;

    // 6. Row 5: ELECTORAL DETAILS (Spanning across or in left cell)
    drawCell(col1X, curY, contentWidth, 5.2, 'ELECTORAL DETAILS', true, 8.5);
    curY += 5.2;

    // 7. Row 6: EPIC Number | AC Number
    drawCell(col1X, curY, col1W, rowH, 'EPIC Number', true, 8);
    drawCell(col2X, curY, col2W, rowH, m.epicNumber || '', false, 8.5);
    drawCell(col3X, curY, col3W, rowH, 'AC Number', true, 8);
    drawCell(col4X, curY, col4W, rowH, m.acNumber || '', false, 8.5);
    curY += rowH;

    // 8. Row 7: PART Number | Serial Number
    drawCell(col1X, curY, col1W, rowH, 'PART Number', true, 8);
    drawCell(col2X, curY, col2W, rowH, m.partNumber || '', false, 8.5);
    drawCell(col3X, curY, col3W, rowH, 'Serial Number', true, 8);
    drawCell(col4X, curY, col4W, rowH, m.serialNumber || '', false, 8.5);
    curY += rowH;

    return curY;
  };

  // =========================================================================
  // PAGE 1: EXACT MATCH TO UPLOADED SCREENSHOT
  // =========================================================================
  
  // Title (Centered, bold uppercase)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(15, 15, 15);
  doc.text('MUKHYAMANTRI SWASTHYA BIMA YOJANA', pageWidth / 2, 20, { align: 'center' });

  // Subtitle (Centered, normal font)
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Form for New Enrollment — West Bengal', pageWidth / 2, 26, { align: 'center' });

  // Date (Right aligned, bold)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  const dateStr = formData.formDate || new Date().toLocaleDateString('en-GB');
  doc.text(`DATE: ${dateStr}`, pageWidth - marginX, 36, { align: 'right' });

  // Member 1
  let nextY = drawMemberBlock(42, 1, formData.members[0]);

  // Member 2
  nextY = drawMemberBlock(nextY + 6, 2, formData.members[1]);

  // Member 3
  nextY = drawMemberBlock(nextY + 6, 3, formData.members[2]);

  // Page 1 Footer
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text('Page 1 of 3 — Mukhyamantri Swasthya Bima Yojana', pageWidth / 2, pageHeight - 8, { align: 'center' });

  // =========================================================================
  // PAGE 2: MEMBERS 4, 5, 6
  // =========================================================================
  doc.addPage('a4', 'portrait');

  // Page 2 Title Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 15, 15);
  doc.text('MUKHYAMANTRI SWASTHYA BIMA YOJANA', pageWidth / 2, 18, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.text('Additional Beneficiary Members (Page 2 of 3)', pageWidth / 2, 23.5, { align: 'center' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text(`DATE: ${dateStr}`, pageWidth - marginX, 30, { align: 'right' });

  // Member 4
  let p2Y = drawMemberBlock(35, 4, formData.members[3]);

  // Member 5
  p2Y = drawMemberBlock(p2Y + 6, 5, formData.members[4]);

  // Member 6
  p2Y = drawMemberBlock(p2Y + 6, 6, formData.members[5]);

  // Page 2 Footer
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text('Page 2 of 3 — Mukhyamantri Swasthya Bima Yojana', pageWidth / 2, pageHeight - 8, { align: 'center' });

  // =========================================================================
  // PAGE 3: FAMILY DETAILS, ADDRESS, SIGNATURES & OFFICIAL USE (BLANK)
  // =========================================================================
  doc.addPage('a4', 'portrait');

  // Page 3 Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.setTextColor(15, 15, 15);
  doc.text('MUKHYAMANTRI SWASTHYA BIMA YOJANA', pageWidth / 2, 18, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.text('Family Details, Address & Verification (Page 3 of 3)', pageWidth / 2, 23.5, { align: 'center' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text(`DATE: ${dateStr}`, pageWidth - marginX, 30, { align: 'right' });

  let p3Y = 36;

  // Section 1: Address Details
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('FAMILY DETAILS & RESIDENTIAL ADDRESS', marginX, p3Y);
  p3Y += 2.5;

  // Full Address Row (Address label 50mm, Address value 132mm)
  const addrRowH = 12;
  drawCell(col1X, p3Y, col1W, addrRowH, 'FULL ADDRESS', true, 8, '(House No/Street/Village/Ward)');
  drawCell(col2X, p3Y, col2W + col3W + col4W, addrRowH, formData.familyDetails.fullAddress || '', false, 8.5);
  p3Y += addrRowH;

  // District | Block/ULB
  drawCell(col1X, p3Y, col1W, rowH, 'DISTRICT', true, 8);
  drawCell(col2X, p3Y, col2W, rowH, formData.familyDetails.district || '', true, 8.5);
  drawCell(col3X, p3Y, col3W, rowH, 'BLOCK / ULB', true, 8);
  drawCell(col4X, p3Y, col4W, rowH, formData.familyDetails.blockUlb || '', false, 8.5);
  p3Y += rowH;

  // Gram Panchayat / Ward | Family Head Name
  drawCell(col1X, p3Y, col1W, rowH, 'GRAM PANCHAYAT / WARD', true, 8);
  drawCell(col2X, p3Y, col2W, rowH, formData.familyDetails.gramPanchayatWard || '', false, 8.5);
  drawCell(col3X, p3Y, col3W, rowH, 'FAMILY HEAD NAME', true, 8);
  drawCell(col4X, p3Y, col4W, rowH, formData.familyDetails.familyHeadName || '', true, 8.5);
  p3Y += rowH;

  // Total Members | SS URN No
  drawCell(col1X, p3Y, col1W, rowH, 'TOTAL FAMILY MEMBERS', true, 8);
  drawCell(col2X, p3Y, col2W, rowH, String(formData.familyDetails.totalFamilyMembers || 1), true, 8.5);
  drawCell(col3X, p3Y, col3W, rowH, 'SS URN NO. (17-DIGIT)', true, 8);
  drawCell(col4X, p3Y, col4W, rowH, formData.familyDetails.ssUrnNo || '', true, 8.5, undefined, false, [0, 0, 140]);
  p3Y += rowH + 6;

  // Section 2: Beneficiary Declaration & Signature
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('DECLARATION AND SIGNATURE OF BENEFICIARY', marginX, p3Y);
  p3Y += 2.5;

  const declText = 'I hereby declare that all the information provided above is true and correct to the best of my knowledge. I understand that any false statement will result in disqualification under Mukhyamantri Swasthya Bima Yojana.';
  doc.setDrawColor(40, 40, 40);
  doc.setLineWidth(0.35);
  doc.rect(marginX, p3Y, contentWidth, 11);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7.5);
  doc.setTextColor(40, 40, 40);
  doc.text(declText, marginX + 3, p3Y + 4.5, { maxWidth: contentWidth - 6 });
  p3Y += 11;

  // Contact person & Signature Row
  const sigRowH = 14;
  drawCell(col1X, p3Y, col1W, sigRowH, 'Name and Contact Number\nof Beneficiary', true, 8);
  drawCell(col2X, p3Y, col2W, sigRowH, formData.familyDetails.beneficiaryNameContact || '', false, 8);
  drawCell(col3X, p3Y, col3W, sigRowH, 'Signature / LTI of the Beneficiary', true, 8);
  
  // Beneficiary Signature value Box
  doc.setDrawColor(40, 40, 40);
  doc.setLineWidth(0.35);
  doc.rect(col4X, p3Y, col4W, sigRowH);
  if (formData.familyDetails.beneficiarySignature) {
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(9.5);
    doc.setTextColor(0, 0, 130);
    doc.text(formData.familyDetails.beneficiarySignature, col4X + 3, p3Y + 8);
  }
  p3Y += sigRowH + 10;

  // Section 3: STRICTLY OFFICIAL USE SECTION (KEPT COMPLETELY BLANK AS REQUESTED)
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 15, 15);
  doc.text('FOR OFFICIAL USE ONLY (NOT TO BE FILLED BY APPLICANT)', marginX, p3Y);
  p3Y += 2.5;

  const offRowH1 = 12;
  const offRowH2 = 18;

  // Row 1: Receiving Authority details (BLANK)
  drawCell(col1X, p3Y, 60, offRowH1, 'Receiving Authority Name, Designation,\nContact Number', true, 7.5);
  drawCell(col1X + 60, p3Y, contentWidth - 60, offRowH1, '', false, 8.5); // Strictly blank
  p3Y += offRowH1;

  // Row 2: Receiving Authority Signature & Seal (BLANK)
  drawCell(col1X, p3Y, 60, offRowH2, 'Receiving Authority Signature\n& Official Stamp / Seal', true, 7.5);
  drawCell(col1X + 60, p3Y, contentWidth - 60, offRowH2, '', false, 8.5); // Strictly blank
  p3Y += offRowH2;

  // Official verification footnote
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.setTextColor(90, 90, 90);
  doc.text('Note: The above official section will be completed, signed, and stamped by the designated Govt. Officer upon physical verification.', marginX, p3Y + 4);

  // Page 3 Footer
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text('Page 3 of 3 — Mukhyamantri Swasthya Bima Yojana', pageWidth / 2, pageHeight - 8, { align: 'center' });

  return doc;
};
