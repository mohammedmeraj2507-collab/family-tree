import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const SahajBengalLogo: React.FC<LogoProps> = ({ 
  className = '', 
  size = 'md',
}) => {
  const sizeMap = {
    sm: 'w-7 h-7',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-20 h-20',
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  return (
    <div className={`relative inline-flex items-center justify-center flex-shrink-0 ${currentSize} ${className}`}>
      {/* Outer Golden Glow & Border Ring */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-500 via-orange-400 to-amber-300 p-0.5 shadow-md shadow-amber-500/25">
        <div className="w-full h-full rounded-full bg-gradient-to-b from-emerald-950 via-slate-900 to-amber-950 flex items-center justify-center overflow-hidden relative">
          
          {/* Subtle Radial Glow */}
          <div className="absolute inset-0 bg-radial-at-c from-amber-400/25 via-transparent to-transparent"></div>
          
          {/* Official Emblem Graphic */}
          <svg 
            viewBox="0 0 100 100" 
            className="w-[86%] h-[86%] drop-shadow-sm select-none"
            fill="none" 
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Outer Decorative Ring */}
            <circle cx="50" cy="50" r="46" stroke="#f59e0b" strokeWidth="2.5" strokeDasharray="2 1.5" />
            <circle cx="50" cy="50" r="41" stroke="#fbbf24" strokeWidth="1.2" />

            {/* Rising Sun Motif at Top */}
            <path d="M36 34 L50 20 L64 34 Z" fill="url(#sunGrad)" opacity="0.9" />
            <circle cx="50" cy="30" r="7" fill="#f59e0b" />
            <path d="M50 14 L50 19 M38 18 L41 22 M62 18 L59 22 M30 27 L35 29 M70 27 L65 29" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />

            {/* Stylized Bengali "বা" / Biswa Bangla Globe Spiral */}
            <path 
              d="M32 60 C 30 45, 45 38, 55 42 C 65 46, 68 58, 58 68 C 48 77, 36 70, 36 58 C 36 49, 44 45, 50 46 C 56 47, 58 53, 55 57 C 52 61, 46 60, 46 55" 
              stroke="url(#bengalGrad)" 
              strokeWidth="4.5" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
            />

            {/* Golden Ashoka Chakra Dots */}
            <circle cx="50" cy="50" r="2.5" fill="#fef08a" />
            <circle cx="28" cy="50" r="1.8" fill="#fbbf24" />
            <circle cx="72" cy="50" r="1.8" fill="#fbbf24" />

            {/* Bottom Laurel / Rice Grain Leaves (Bengal Heritage) */}
            <path d="M22 68 Q 34 82 50 84 Q 66 82 78 68" stroke="#10b981" strokeWidth="2" fill="none" strokeLinecap="round" />
            <path d="M26 64 C 29 70 34 74 40 76 M74 64 C 71 70 66 74 60 76" stroke="#34d399" strokeWidth="1.6" strokeLinecap="round" />

            {/* Gradients */}
            <defs>
              <linearGradient id="sunGrad" x1="50" y1="20" x2="50" y2="34" gradientUnits="userSpaceOnUse">
                <stop stopColor="#fbbf24" />
                <stop offset="1" stopColor="#d97706" />
              </linearGradient>
              <linearGradient id="bengalGrad" x1="30" y1="38" x2="70" y2="76" gradientUnits="userSpaceOnUse">
                <stop stopColor="#fef08a" />
                <stop offset="0.5" stopColor="#f59e0b" />
                <stop offset="1" stopColor="#ea580c" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
    </div>
  );
};
