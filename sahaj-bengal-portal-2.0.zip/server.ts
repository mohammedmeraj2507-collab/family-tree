import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Shared Gemini AI client helper (lazy initialization)
  function getGeminiClient() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is missing.');
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // AI Form Scanner Endpoint: Scans uploaded form pages/images, detects fields and generates schema
  app.post('/api/scan-form', async (req, res) => {
    try {
      const { imageBase64, mimeType = 'image/jpeg', formNameHint } = req.body;
      if (!imageBase64) {
        return res.status(400).json({ error: 'imageBase64 image data is required' });
      }

      // Check if API key is present
      if (!process.env.GEMINI_API_KEY) {
        return res.status(503).json({
          error: 'GEMINI_API_KEY not configured. Using intelligent template scanner fallback.',
          fallback: true,
        });
      }

      const ai = getGeminiClient();

      const prompt = `You are an expert Document Analysis and Government Form Digitization AI.
Analyze the provided form document image and convert it into a structured Data Entry schema for Cyber Cafe operators.

CRITICAL RULES:
1. Identify Form Title, State / Authority, Subtitle, and Date format.
2. Identify all Sections (e.g. Beneficiary Details, Member Details, Electoral Details, Family Details, Address, Contact).
3. Identify all individual input fields with:
   - id: unique camelCase identifier
   - label: clear readable label
   - type: text | number | date | select | textarea | phone | aadhar | pan | voter_id
   - options: array of options if type is select (e.g. AAY, SPHH, PHH, RKSY-1, RKSY-2, GEN or M/F/O)
   - required: boolean
   - placeholder: string
   - helpText: optional string
   - section: section name
4. EXCLUDE OFFICIAL USE ONLY FIELDS: Any section marked "For Official Use Only", "Receiving Authority", "Officer Signature", "Verification Remarks" MUST have isOfficialUse: true or be marked so that Cyber Cafe / User data entry leaves it blank.
5. If the form has repeating member rows (e.g. Member 1, Member 2, Member 3...), extract the template schema for a single member and indicate the maximum supported members.

Return the result strictly as a valid JSON object matching the requested schema.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: {
          parts: [
            {
              inlineData: {
                data: imageBase64.replace(/^data:image\/\w+;base64,/, ''),
                mimeType: mimeType || 'image/jpeg',
              },
            },
            {
              text: prompt + (formNameHint ? `\nHint for form name: ${formNameHint}` : ''),
            },
          ],
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING, description: 'Official Title of the form' },
              subtitle: { type: Type.STRING, description: 'Subtitle or description (e.g. West Bengal Enrollment)' },
              stateOrAuthority: { type: Type.STRING, description: 'State or Authority name' },
              totalPages: { type: Type.INTEGER, description: 'Estimated page count' },
              sections: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    name: { type: Type.STRING },
                    description: { type: Type.STRING },
                    isRepeating: { type: Type.BOOLEAN },
                    maxRepeats: { type: Type.INTEGER },
                    isOfficialUseOnly: { type: Type.BOOLEAN },
                    fields: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          id: { type: Type.STRING },
                          label: { type: Type.STRING },
                          type: { type: Type.STRING },
                          options: { type: Type.ARRAY, items: { type: Type.STRING } },
                          placeholder: { type: Type.STRING },
                          required: { type: Type.BOOLEAN },
                          isOfficialUse: { type: Type.BOOLEAN },
                        },
                        required: ['id', 'label', 'type'],
                      },
                    },
                  },
                  required: ['id', 'name', 'fields'],
                },
              },
            },
            required: ['title', 'sections'],
          },
        },
      });

      const extractedJson = JSON.parse(response.text || '{}');
      return res.json({ success: true, schema: extractedJson });
    } catch (err: any) {
      console.error('Error scanning form:', err);
      return res.status(500).json({ error: err.message || 'Failed to scan form' });
    }
  });

  // Vite integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Cyber Cafe Form System running on port ${PORT}`);
  });
}

startServer();
