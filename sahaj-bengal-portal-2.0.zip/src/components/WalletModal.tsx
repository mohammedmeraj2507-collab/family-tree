import React, { useState } from 'react';
import { 
  X, 
  Wallet, 
  PlusCircle, 
  IndianRupee, 
  CheckCircle, 
  ArrowUpRight, 
  QrCode, 
  ShieldCheck, 
  Sparkles,
  CreditCard,
  Building2
} from 'lucide-react';
import { CyberCafeProfile } from '../types';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  cafeProfile: CyberCafeProfile;
  onAddBalance: (amount: number) => void;
  lang: 'bn' | 'en';
}

export const WalletModal: React.FC<WalletModalProps> = ({
  isOpen,
  onClose,
  cafeProfile,
  onAddBalance,
  lang,
}) => {
  const [selectedAmount, setSelectedAmount] = useState<number>(100);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleRecharge = () => {
    onAddBalance(selectedAmount);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1500);
  };

  const presetAmounts = [50, 100, 200, 500, 1000];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">
                {lang === 'bn' ? 'সাইবার ক্যাফে ওয়ালেট রিচার্জ' : 'Cyber Cafe Wallet Management'}
              </h3>
              <p className="text-xs text-slate-400">
                {lang === 'bn' ? 'ফর্ম ডাউনলোড টোকেন ব্যালেন্স' : 'Form Download Token System (₹10 / Download)'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Current Balance Card */}
          <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-5 rounded-xl border border-slate-800 text-white flex items-center justify-between shadow-md">
            <div>
              <div className="text-xs text-slate-400 font-medium">
                {lang === 'bn' ? 'বর্তমান অবশিষ্ট ব্যালেন্স' : 'Current Available Balance'}
              </div>
              <div className="text-3xl font-extrabold text-emerald-400 mt-1 flex items-center gap-1">
                <IndianRupee className="w-6 h-6" />
                {cafeProfile.walletBalance}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {lang === 'bn' 
                  ? `মোট ${(cafeProfile.walletBalance / 10).toFixed(0)} টি ফর্ম ডাউনলোড করতে পারবেন` 
                  : `Equivalent to ${Math.floor(cafeProfile.walletBalance / 10)} Form Downloads`}
              </div>
            </div>

            <div className="text-right">
              <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded-full border border-emerald-700">
                <ShieldCheck className="w-3.5 h-3.5" />
                {lang === 'bn' ? 'সক্রিয়' : 'Active'}
              </span>
            </div>
          </div>

          {/* Quick Preset Buttons */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
              {lang === 'bn' ? 'রিচার্জ পরিমাণ নির্বাচন করুন (টাকা)' : 'Select Recharge Amount (INR)'}
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {presetAmounts.map((amt) => (
                <button
                  key={amt}
                  onClick={() => setSelectedAmount(amt)}
                  className={`py-2.5 px-3 rounded-xl font-bold text-sm transition border flex flex-col items-center justify-center ${
                    selectedAmount === amt
                      ? 'bg-emerald-50 dark:bg-emerald-950 border-emerald-500 text-emerald-700 dark:text-emerald-300 ring-2 ring-emerald-500/30'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                  }`}
                >
                  <span>₹{amt}</span>
                  <span className="text-[10px] text-slate-400 font-normal mt-0.5">
                    {amt / 10} {lang === 'bn' ? 'ফর্ম' : 'Forms'}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Recharge Methods Banner */}
          <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
            <div className="flex items-center gap-2">
              <QrCode className="w-5 h-5 text-indigo-500" />
              <span>{lang === 'bn' ? 'UPI, QR কোড ও নেট ব্যাংকিং সমর্থিত' : 'Instant UPI, QR & NetBanking Simulation'}</span>
            </div>
            <span className="text-emerald-500 font-bold">0% {lang === 'bn' ? 'ফি' : 'Fee'}</span>
          </div>

          {/* Action Button */}
          <div>
            {isSuccess ? (
              <div className="p-3 bg-emerald-500 text-slate-950 rounded-xl font-bold text-center flex items-center justify-center gap-2">
                <CheckCircle className="w-5 h-5" />
                <span>{lang === 'bn' ? 'রিচার্জ সফল হয়েছে!' : 'Recharge Successful!'}</span>
              </div>
            ) : (
              <button
                onClick={handleRecharge}
                className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold py-3 px-4 rounded-xl shadow-lg flex items-center justify-center gap-2 transition active:scale-95"
              >
                <PlusCircle className="w-5 h-5" />
                <span>
                  {lang === 'bn' ? `₹${selectedAmount} রিচার্জ যোগ করুন` : `Add ₹${selectedAmount} to Wallet`}
                </span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
