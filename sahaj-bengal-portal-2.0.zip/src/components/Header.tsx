import React from 'react';
import { 
  FileText, 
  Wallet, 
  PlusCircle, 
  ScanLine, 
  Globe, 
  Building2,
  Phone,
  Lock,
  UserCheck,
  UserPlus,
  LogIn,
  Sun,
  Moon,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { CyberCafeProfile } from '../types';
import { SahajBengalLogo } from './SahajBengalLogo';

interface HeaderProps {
  currentTab: 'dashboard' | 'data-entry' | 'scanner';
  setCurrentTab: (tab: 'dashboard' | 'data-entry' | 'scanner') => void;
  cafeProfile: CyberCafeProfile;
  onOpenWallet: () => void;
  onOpenScanner: () => void;
  onOpenAuth: () => void;
  lang: 'bn' | 'en';
  setLang: (lang: 'bn' | 'en') => void;
  themeMode: 'light' | 'dark';
  setThemeMode: (theme: 'light' | 'dark') => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  cafeProfile,
  onOpenWallet,
  onOpenScanner,
  onOpenAuth,
  lang,
  setLang,
  themeMode,
  setThemeMode,
}) => {
  const isLight = themeMode === 'light';
  const isAdmin = cafeProfile.userType === 'admin';

  return (
    <header className={`${isLight ? 'bg-white/95 text-slate-900 border-b border-amber-200/80 shadow-md' : 'bg-slate-950/90 text-amber-50 border-b border-amber-500/20 shadow-2xl shadow-black/80'} backdrop-blur-2xl sticky top-0 z-40 transition-colors duration-300`}>
      {/* Top Cyber Cafe Notice & Contact Bar */}
      <div className={`${isLight ? 'bg-gradient-to-r from-amber-100 via-orange-50 to-amber-100 text-slate-900 border-b border-amber-200' : 'bg-amber-950/40 text-amber-200 border-b border-amber-500/15'} px-4 py-1.5 text-xs flex flex-wrap items-center justify-between gap-2`}>
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className={`font-black flex items-center gap-1.5 ${isLight ? 'text-amber-950' : 'text-amber-300'}`}>
            <Building2 className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400" />
            {isAdmin ? '👑 মাস্টার পোর্টাল অ্যাডমিন (Owner Mode)' : cafeProfile.cafeName}
          </span>
          <span className={`${isLight ? 'text-amber-400' : 'text-amber-700'} hidden sm:inline`}>|</span>
          <span className={`${isLight ? 'text-slate-700 font-bold' : 'text-amber-200/80 font-medium'} hidden md:inline flex items-center gap-1`}>
            <Phone className="w-3 h-3 text-amber-600" />
            {cafeProfile.phone} ({cafeProfile.operatorName})
          </span>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          {/* User / Cyber Cafe / Admin Login Button */}
          <button
            onClick={onOpenAuth}
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full font-black text-xs transition shadow-sm ${
              isAdmin 
                ? 'bg-purple-600 hover:bg-purple-700 text-white border border-purple-400'
                : isLight 
                ? 'bg-amber-500 hover:bg-amber-600 text-slate-950 border border-amber-600/30' 
                : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 border border-amber-400/40'
            }`}
          >
            {cafeProfile.isLoggedIn ? (
              <>
                <UserCheck className="w-3.5 h-3.5" />
                <span>
                  {isAdmin 
                    ? '👑 অ্যাডমিন ওনার' 
                    : cafeProfile.userType === 'shopkeeper'
                    ? `🏪 দোকানদার: ${cafeProfile.operatorName?.split(' ')[0]}`
                    : cafeProfile.userType === 'citizen' 
                    ? `👤 নাগরিক: ${cafeProfile.operatorName?.split(' ')[0]}`
                    : `🏢 ক্যাফে: ${cafeProfile.operatorName?.split(' ')[0]}`}
                </span>
              </>
            ) : (
              <>
                <LogIn className="w-3.5 h-3.5" />
                <span>{lang === 'bn' ? 'লগইন / রেজিস্টার' : 'Login / Register'}</span>
              </>
            )}
          </button>

          <span className={`hidden sm:inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full font-bold ${isLight ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' : 'text-emerald-300 bg-emerald-500/20 border border-emerald-500/40'}`}>
            <Lock className="w-3 h-3 text-emerald-700 dark:text-emerald-400" />
            {lang === 'bn' ? 'অটো-ডিলিট প্রটেকশন' : 'Auto-Wipe Privacy'}
          </span>

          {/* Theme Mode Toggle (Light / Dark) */}
          <button
            onClick={() => setThemeMode(isLight ? 'dark' : 'light')}
            className={`p-1.5 rounded-full border transition ${isLight ? 'bg-amber-100 text-amber-950 border-amber-300 hover:bg-amber-200' : 'bg-slate-800 text-amber-300 border-slate-700 hover:bg-slate-700'}`}
            title={isLight ? 'Switch to Dark Mode' : 'Switch to Light Highlighted Mode'}
          >
            {isLight ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
          </button>

          {/* Language Switch */}
          <button
            onClick={() => setLang(lang === 'bn' ? 'en' : 'bn')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-full border-2 transition text-xs font-black ${
              isLight 
                ? 'bg-white text-slate-900 border-slate-300 hover:bg-amber-50' 
                : 'text-amber-200 hover:text-white bg-amber-500/15 hover:bg-amber-500/25 border-amber-500/30'
            }`}
          >
            <Globe className="w-3 h-3 text-amber-600" />
            <span>{lang === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar with Official West Bengal Emblem Logo */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Official Logo & Website Name (User Request 4: নামের আগে logo) */}
          <div 
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => setCurrentTab('dashboard')}
          >
            {/* Logo Component */}
            <SahajBengalLogo size="md" className="group-hover:scale-105 transition-transform duration-200" />

            <div>
              <div className="flex items-center gap-2">
                <h1 className={`font-black text-base sm:text-xl tracking-tight transition ${isLight ? 'text-slate-950 group-hover:text-amber-800' : 'text-white group-hover:text-amber-300'}`}>
                  SAHAJ BENGAL PORTAL 2.0
                </h1>
                <span className="bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow-sm">
                  {isAdmin ? 'ADMIN' : 'PRO'}
                </span>
              </div>
              <p className={`text-xs hidden sm:block font-bold ${isLight ? 'text-amber-950/80' : 'text-amber-200/80'}`}>
                {lang === 'bn' ? 'পশ্চিমবঙ্গ সরকারি ফর্ম ফিলাপ ও অটো-পিডিএফ জেনারেটর' : 'West Bengal Govt Form Filling & Instant PDF Portal'}
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-2">
            <button
              onClick={() => setCurrentTab('dashboard')}
              className={`px-4 py-2 rounded-xl text-sm font-black transition flex items-center gap-1.5 ${
                currentTab === 'dashboard'
                  ? (isLight ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30' : 'bg-amber-500/30 text-amber-200 border border-amber-500/60')
                  : (isLight ? 'text-slate-800 hover:text-amber-900 hover:bg-amber-100/70' : 'text-amber-100/90 hover:text-white hover:bg-amber-500/15')
              }`}
            >
              <FileText className="w-4 h-4" />
              {isAdmin ? (lang === 'bn' ? 'অ্যাডমিন ড্যাশবোর্ড' : 'Admin Dashboard') : (lang === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard')}
            </button>

            <button
              onClick={() => setCurrentTab('data-entry')}
              className={`px-4 py-2 rounded-xl text-sm font-black transition flex items-center gap-1.5 ${
                currentTab === 'data-entry'
                  ? (isLight ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30' : 'bg-amber-500/30 text-amber-200 border border-amber-500/60')
                  : (isLight ? 'text-slate-800 hover:text-amber-900 hover:bg-amber-100/70' : 'text-amber-100/90 hover:text-white hover:bg-amber-500/15')
              }`}
            >
              <PlusCircle className="w-4 h-4" />
              {lang === 'bn' ? 'ডাটা এন্ট্রি টুল' : 'Data Entry Tool'}
            </button>

            <button
              onClick={onOpenScanner}
              className={`px-4 py-2 rounded-xl text-sm font-black transition flex items-center gap-1.5 shadow-sm ${
                isLight 
                  ? 'bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300' 
                  : 'text-amber-200 hover:text-white bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40'
              }`}
            >
              <ScanLine className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              {lang === 'bn' ? 'AI ফর্ম স্ক্যানার' : 'AI Form Scanner'}
            </button>

            {/* Registration / Login Top Link */}
            <button
              onClick={onOpenAuth}
              className={`px-4 py-2 rounded-xl text-sm font-black transition flex items-center gap-1.5 ${
                isLight 
                  ? 'bg-orange-100 hover:bg-orange-200 text-orange-950 border border-orange-300' 
                  : 'text-orange-200 hover:text-white bg-orange-500/20 border border-orange-500/40'
              }`}
            >
              <UserPlus className="w-4 h-4 text-orange-600 dark:text-orange-400" />
              <span>{isAdmin ? 'মাস্টার অ্যাকাউন্ট' : (lang === 'bn' ? 'রেজিস্ট্রেশন / লগইন' : 'Sign In / Register')}</span>
            </button>
          </nav>

          {/* Right Action Bar & Wallet */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Wallet Button */}
            <button
              onClick={onOpenWallet}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-sm transition group shadow-sm ${
                isLight 
                  ? 'bg-amber-50 hover:bg-amber-100 border-2 border-amber-300 text-slate-950' 
                  : 'bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-100'
              }`}
              title="Cyber Cafe Wallet Balance"
            >
              <div className="w-6 h-6 rounded-full bg-amber-500/30 flex items-center justify-center text-amber-700 dark:text-amber-300">
                <Wallet className="w-3.5 h-3.5 group-hover:scale-110 transition" />
              </div>
              <div className="text-left">
                <div className={`text-[10px] font-bold leading-none ${isLight ? 'text-slate-600' : 'text-amber-200/80'}`}>
                  {lang === 'bn' ? 'ব্যালেন্স' : 'Balance'}
                </div>
                <div className={`text-sm font-black leading-tight ${isLight ? 'text-amber-950' : 'text-amber-300'}`}>
                  ₹{cafeProfile.walletBalance}
                </div>
              </div>
              <span className="text-[11px] text-slate-950 bg-amber-400 hover:bg-amber-300 px-2 py-0.5 rounded-md font-black transition">
                + রিচার্জ
              </span>
            </button>

            {/* Quick Data Entry CTA */}
            <button
              onClick={() => setCurrentTab('data-entry')}
              className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black px-4 py-2 rounded-xl text-xs sm:text-sm shadow-md shadow-amber-500/30 flex items-center gap-1.5 transition active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{lang === 'bn' ? 'নতুন এন্ট্রি' : 'New Entry'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className={`lg:hidden flex items-center justify-around border-t px-2 py-1.5 text-xs ${isLight ? 'bg-amber-50/95 border-amber-200 text-slate-900 font-bold' : 'bg-slate-950/95 border-amber-500/20 text-amber-200/80'}`}>
        <button
          onClick={() => setCurrentTab('dashboard')}
          className={`flex-1 py-2 text-center font-black rounded-lg transition ${
            currentTab === 'dashboard' ? (isLight ? 'text-slate-950 bg-amber-400 shadow-sm' : 'text-amber-300 bg-amber-500/25 border border-amber-500/40') : ''
          }`}
        >
          {lang === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard'}
        </button>
        <button
          onClick={() => setCurrentTab('data-entry')}
          className={`flex-1 py-2 text-center font-black rounded-lg transition ${
            currentTab === 'data-entry' ? (isLight ? 'text-slate-950 bg-amber-400 shadow-sm' : 'text-amber-300 bg-amber-500/25 border border-amber-500/40') : ''
          }`}
        >
          {lang === 'bn' ? 'ডাটা এন্ট্রি' : 'Data Entry'}
        </button>
        <button
          onClick={onOpenScanner}
          className="flex-1 py-2 text-center font-black text-amber-700 dark:text-amber-400"
        >
          {lang === 'bn' ? 'AI স্ক্যান' : 'AI Scan'}
        </button>
        <button
          onClick={onOpenAuth}
          className="flex-1 py-2 text-center font-black text-orange-700 dark:text-orange-400"
        >
          {lang === 'bn' ? 'লগইন' : 'Login'}
        </button>
      </div>
    </header>
  );
};
