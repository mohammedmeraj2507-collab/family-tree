import React, { useState } from 'react';
import { 
  X, 
  Building2, 
  User, 
  Lock, 
  Phone, 
  Mail, 
  MapPin, 
  ShieldCheck, 
  Sparkles, 
  ArrowRight, 
  CheckCircle2, 
  KeyRound,
  LogIn,
  UserPlus,
  BadgeCheck,
  Store,
  Crown
} from 'lucide-react';
import { CyberCafeProfile } from '../types';
import { SahajBengalLogo } from './SahajBengalLogo';

interface UserAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  cafeProfile: CyberCafeProfile;
  onSaveProfile: (profile: CyberCafeProfile) => void;
  lang: 'bn' | 'en';
}

export const UserAuthModal: React.FC<UserAuthModalProps> = ({
  isOpen,
  onClose,
  cafeProfile,
  onSaveProfile,
  lang,
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'admin'>('login');
  const [userRole, setUserRole] = useState<'cyber_cafe' | 'shopkeeper' | 'citizen' | 'admin'>('cyber_cafe');

  // Form states
  const [cafeName, setCafeName] = useState(cafeProfile.cafeName || 'Bengal Digital Seva Kendra');
  const [operatorName, setOperatorName] = useState(cafeProfile.operatorName || 'Sourav Mondal');
  const [cscId, setCscId] = useState(cafeProfile.cscId || 'WB-CSC-884920');
  const [phone, setPhone] = useState(cafeProfile.phone || '9876543210');
  const [email, setEmail] = useState(cafeProfile.email || 'cybercafe.wb@gmail.com');
  const [district, setDistrict] = useState(cafeProfile.location || 'North 24 Parganas');
  const [securityPin, setSecurityPin] = useState('1234');
  const [adminPin, setAdminPin] = useState('');

  const [notification, setNotification] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (authMode === 'admin') {
      if (adminPin === '1234' || adminPin === 'admin' || email === 'halbuju120@gmail.com') {
        const adminProfile: CyberCafeProfile = {
          cafeName: 'SAHAJ BENGAL MASTER PORTAL',
          operatorName: 'Portal Master Admin (Owner)',
          phone: phone || '9830000000',
          location: 'Kolkata Head Office',
          walletBalance: 99999,
          email: 'halbuju120@gmail.com',
          userType: 'admin',
          userRole: 'admin',
          isLoggedIn: true,
        };
        onSaveProfile(adminProfile);
        setNotification(lang === 'bn' ? 'মাস্টার অ্যাডমিন মোডে সফলভাবে লগইন হয়েছে!' : 'Admin Mode Logged In Successfully!');
        setTimeout(() => {
          setNotification(null);
          onClose();
        }, 1000);
        return;
      } else {
        alert(lang === 'bn' ? 'ভুল অ্যাডমিন পিন! (সঠিক পিন: 1234)' : 'Incorrect Admin PIN! (Default PIN: 1234)');
        return;
      }
    }

    const updatedProfile: CyberCafeProfile = {
      cafeName: userRole === 'citizen' ? `${operatorName} (Citizen Account)` : cafeName,
      operatorName: operatorName,
      phone: phone,
      location: district,
      walletBalance: cafeProfile.walletBalance || 500,
      cscId: userRole === 'cyber_cafe' ? cscId : undefined,
      email: email,
      userType: userRole,
      userRole: userRole,
      isLoggedIn: true,
    };

    onSaveProfile(updatedProfile);
    setNotification(
      lang === 'bn' 
        ? `${authMode === 'login' ? 'লগইন' : 'রেজিস্ট্রেশন'} সফল হয়েছে!` 
        : `${authMode === 'login' ? 'Login' : 'Registration'} Successful!`
    );

    setTimeout(() => {
      setNotification(null);
      onClose();
    }, 1000);
  };

  const handleQuickDemoLogin = (role: 'cyber_cafe' | 'shopkeeper' | 'citizen' | 'admin') => {
    if (role === 'admin') {
      const demoProfile: CyberCafeProfile = {
        cafeName: 'SAHAJ BENGAL 2.0 (Master Admin)',
        operatorName: 'Portal Master Admin',
        phone: '9830000000',
        location: 'Kolkata HQ',
        walletBalance: 99999,
        email: 'halbuju120@gmail.com',
        userType: 'admin',
        userRole: 'admin',
        isLoggedIn: true,
      };
      onSaveProfile(demoProfile);
    } else if (role === 'shopkeeper') {
      const demoProfile: CyberCafeProfile = {
        cafeName: 'Maa Tara Online Corner (দোকানদার)',
        operatorName: 'Subir Roy (Shop Owner)',
        phone: '9832145678',
        location: 'Hooghly',
        walletBalance: 650,
        email: 'subir.shop@gmail.com',
        userType: 'shopkeeper',
        userRole: 'shopkeeper',
        isLoggedIn: true,
      };
      onSaveProfile(demoProfile);
    } else if (role === 'cyber_cafe') {
      const demoProfile: CyberCafeProfile = {
        cafeName: 'Bengal Digital Seva Kendra (CSC)',
        operatorName: 'Ramesh Sen (VLE)',
        phone: '9830012345',
        location: 'Kolkata / North 24 Pgs',
        walletBalance: 500,
        cscId: 'WB-VLE-77821',
        email: 'bengal.csc@gov.in',
        userType: 'cyber_cafe',
        userRole: 'cyber_cafe',
        isLoggedIn: true,
      };
      onSaveProfile(demoProfile);
    } else {
      const demoProfile: CyberCafeProfile = {
        cafeName: 'Ananya Mukherjee (Citizen)',
        operatorName: 'Ananya Mukherjee',
        phone: '9874561230',
        location: 'South 24 Parganas',
        walletBalance: 200,
        email: 'ananya.m@gmail.com',
        userType: 'citizen',
        userRole: 'citizen',
        isLoggedIn: true,
      };
      onSaveProfile(demoProfile);
    }

    setNotification(lang === 'bn' ? 'সরাসরি লগইন সম্পন্ন হয়েছে!' : 'Demo Login Successful!');
    setTimeout(() => {
      setNotification(null);
      onClose();
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white border-2 border-amber-400 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Top Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <SahajBengalLogo size="sm" />
            <div>
              <h3 className="font-black text-base sm:text-lg tracking-tight">
                {authMode === 'admin' 
                  ? '👑 পোর্টাল ওনার / মাস্টার অ্যাডমিন লগইন' 
                  : (authMode === 'login' ? 'ইউজার / সাইবার ক্যাফে / দোকানদার লগইন' : 'নতুন অ্যাকাউন্ট রেজিস্ট্রেশন')}
              </h3>
              <p className="text-xs text-slate-950/80 font-bold">
                SAHAJ BENGAL PORTAL 2.0 • Official Access
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-950 hover:bg-slate-950/10 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Notification Toast */}
        {notification && (
          <div className="bg-emerald-500 text-slate-950 px-4 py-2.5 text-xs font-black flex items-center justify-center gap-2 shadow-inner">
            <CheckCircle2 className="w-4 h-4" />
            <span>{notification}</span>
          </div>
        )}

        <div className="p-6 space-y-5">
          {/* Mode Switcher: Login vs Register vs Admin */}
          <div className="grid grid-cols-3 p-1 bg-slate-100 rounded-2xl border border-slate-300 gap-1">
            <button
              type="button"
              onClick={() => { setAuthMode('login'); setUserRole('cyber_cafe'); }}
              className={`py-2 text-xs font-black rounded-xl transition flex items-center justify-center gap-1 ${
                authMode === 'login'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-700 hover:text-slate-950'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'লগইন' : 'Login'}</span>
            </button>

            <button
              type="button"
              onClick={() => { setAuthMode('register'); setUserRole('cyber_cafe'); }}
              className={`py-2 text-xs font-black rounded-xl transition flex items-center justify-center gap-1 ${
                authMode === 'register'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-700 hover:text-slate-950'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'রেজিস্ট্রেশন' : 'Register'}</span>
            </button>

            <button
              type="button"
              onClick={() => { setAuthMode('admin'); setUserRole('admin'); }}
              className={`py-2 text-xs font-black rounded-xl transition flex items-center justify-center gap-1 ${
                authMode === 'admin'
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'text-purple-800 hover:text-purple-950 font-extrabold'
              }`}
            >
              <Crown className="w-3.5 h-3.5" />
              <span>{lang === 'bn' ? 'মালিক / Admin' : 'Admin Owner'}</span>
            </button>
          </div>

          {/* If not Admin Mode: Select Role (Cyber Cafe, Shopkeeper, Citizen) */}
          {authMode !== 'admin' && (
            <div>
              <label className="block text-xs font-black text-slate-900 mb-2">
                {lang === 'bn' ? 'অ্যাকাউন্টের ধরন নির্বাচন করুন:' : 'Select Account Type:'}
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setUserRole('cyber_cafe')}
                  className={`p-2.5 rounded-2xl border-2 text-left transition flex flex-col justify-between ${
                    userRole === 'cyber_cafe'
                      ? 'border-amber-500 bg-amber-50 text-slate-950 font-black shadow-sm'
                      : 'border-slate-300 bg-white text-slate-700 font-bold'
                  }`}
                >
                  <div className="p-1.5 rounded-xl bg-amber-100 text-amber-800 w-fit mb-1">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div className="text-xs font-black text-slate-950">
                    {lang === 'bn' ? 'সাইবার ক্যাফে' : 'Cyber Cafe'}
                  </div>
                  <div className="text-[10px] text-slate-500">CSC / VLE</div>
                </button>

                <button
                  type="button"
                  onClick={() => setUserRole('shopkeeper')}
                  className={`p-2.5 rounded-2xl border-2 text-left transition flex flex-col justify-between ${
                    userRole === 'shopkeeper'
                      ? 'border-amber-500 bg-amber-50 text-slate-950 font-black shadow-sm'
                      : 'border-slate-300 bg-white text-slate-700 font-bold'
                  }`}
                >
                  <div className="p-1.5 rounded-xl bg-amber-100 text-amber-800 w-fit mb-1">
                    <Store className="w-4 h-4" />
                  </div>
                  <div className="text-xs font-black text-slate-950">
                    {lang === 'bn' ? 'দোকানদার' : 'Shopkeeper'}
                  </div>
                  <div className="text-[10px] text-slate-500">Online Store</div>
                </button>

                <button
                  type="button"
                  onClick={() => setUserRole('citizen')}
                  className={`p-2.5 rounded-2xl border-2 text-left transition flex flex-col justify-between ${
                    userRole === 'citizen'
                      ? 'border-amber-500 bg-amber-50 text-slate-950 font-black shadow-sm'
                      : 'border-slate-300 bg-white text-slate-700 font-bold'
                  }`}
                >
                  <div className="p-1.5 rounded-xl bg-amber-100 text-amber-800 w-fit mb-1">
                    <User className="w-4 h-4" />
                  </div>
                  <div className="text-xs font-black text-slate-950">
                    {lang === 'bn' ? 'সাধারণ নাগরিক' : 'Citizen'}
                  </div>
                  <div className="text-[10px] text-slate-500">Personal</div>
                </button>
              </div>
            </div>
          )}

          {/* Admin Mode Specific Login Box */}
          {authMode === 'admin' ? (
            <form onSubmit={handleSubmit} className="space-y-4 bg-purple-50 p-5 rounded-2xl border-2 border-purple-200">
              <div className="flex items-center gap-2 mb-2 text-purple-900 font-black text-sm">
                <Crown className="w-4 h-4 text-purple-700" />
                <span>মাস্টার পোর্টাল অ্যাডমিন অ্যাক্সেস (Owner Master Access)</span>
              </div>
              <p className="text-xs text-purple-800 font-medium">
                অ্যাডমিন মোডে লগইন করলে আপনি সমস্ত সাইবার ক্যাফে ও দোকানদারদের মাস্টার ড্যাশবোর্ড, ব্যালেন্স ট্র্যাকিং এবং কন্ট্রোল প্যানেল দেখতে পাবেন।
              </p>

              <div>
                <label className="block text-xs font-black text-slate-900 mb-1">
                  অ্যাডমিন সিকিউরিটি পিন / পাসওয়ার্ড (Default PIN: 1234)
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-purple-600 absolute left-3 top-3.5" />
                  <input
                    type="password"
                    required
                    value={adminPin}
                    onChange={(e) => setAdminPin(e.target.value)}
                    placeholder="Enter Admin PIN (1234)"
                    className="w-full pl-9 pr-3 py-2.5 bg-white border-2 border-purple-300 rounded-xl text-sm font-mono font-bold text-slate-950 focus:border-purple-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-purple-700 hover:bg-purple-800 text-white font-black py-3 px-5 rounded-xl shadow-lg flex items-center justify-center gap-2 transition active:scale-95 text-sm"
              >
                <Crown className="w-4 h-4" />
                <span>মাস্টার অ্যাডমিন হিসেবে প্রবেশ করুন</span>
              </button>
            </form>
          ) : (
            /* Regular User / Shopkeeper / Cyber Cafe Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              {userRole !== 'citizen' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-black text-slate-900 mb-1">
                      {userRole === 'shopkeeper' ? 'দোকানের নাম *' : 'সাইবার ক্যাফে / সেন্টারের নাম *'}
                    </label>
                    <div className="relative">
                      <Store className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                      <input
                        type="text"
                        required
                        value={cafeName}
                        onChange={(e) => setCafeName(e.target.value)}
                        placeholder="যেমন: Maa Tara Digital Center"
                        className="w-full pl-9 pr-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs font-bold text-slate-950 focus:border-amber-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-black text-slate-900 mb-1">
                      {lang === 'bn' ? 'CSC ID / দোকান লাইসেন্স' : 'CSC ID / Trade No'}
                    </label>
                    <div className="relative">
                      <BadgeCheck className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                      <input
                        type="text"
                        value={cscId}
                        onChange={(e) => setCscId(e.target.value)}
                        placeholder="WB-SHOP-1234"
                        className="w-full pl-9 pr-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs font-bold text-slate-950 focus:border-amber-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-black text-slate-900 mb-1">
                    {lang === 'bn' ? 'অপারেটর / প্রোপাইটার নাম *' : 'Operator / Owner Name *'}
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                    <input
                      type="text"
                      required
                      value={operatorName}
                      onChange={(e) => setOperatorName(e.target.value)}
                      placeholder="পুরো নাম লিখুন"
                      className="w-full pl-9 pr-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs font-bold text-slate-950 focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-900 mb-1">
                    {lang === 'bn' ? 'মোবাইল নম্বর *' : 'Mobile Number *'}
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      value={phone}
                      onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                      placeholder="১০ ডিজিট মোবাইল নম্বর"
                      className="w-full pl-9 pr-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-950 focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-black text-slate-900 mb-1">
                    {lang === 'bn' ? 'জেলা (District) *' : 'District *'}
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                    <input
                      type="text"
                      required
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      placeholder="যেমন: North 24 Parganas"
                      className="w-full pl-9 pr-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs font-bold text-slate-950 focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-900 mb-1">
                    {lang === 'bn' ? 'সিকিউরিটি পিন *' : 'Security PIN *'}
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                    <input
                      type="password"
                      required
                      value={securityPin}
                      onChange={(e) => setSecurityPin(e.target.value)}
                      placeholder="৪ ডিজিট পিন"
                      className="w-full pl-9 pr-3 py-2.5 bg-white border-2 border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-950 focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black py-3 px-5 rounded-2xl shadow-xl shadow-amber-500/25 flex items-center justify-center gap-2 transition active:scale-95 text-xs sm:text-sm"
                >
                  {authMode === 'login' ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                  <span>
                    {authMode === 'login'
                      ? (lang === 'bn' ? 'পোর্টালে প্রবেশ করুন (Sign In)' : 'Sign In to Portal')
                      : (lang === 'bn' ? 'অ্যাকাউন্ট তৈরি করুন (Complete)' : 'Complete Registration')}
                  </span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>
              </div>
            </form>
          )}

          {/* Quick Demo Instant Logins */}
          <div className="pt-3 border-t border-slate-200">
            <div className="text-[11px] font-black text-slate-600 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>{lang === 'bn' ? 'দ্রুত টেস্ট লগইন (১-ক্লিক ডেমো):' : '1-Click Quick Demo Login:'}</span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('cyber_cafe')}
                className="bg-amber-100 hover:bg-amber-200 text-slate-950 font-bold p-2.5 rounded-xl border border-amber-300 text-xs text-left transition flex items-center gap-1.5 shadow-sm"
              >
                <Building2 className="w-4 h-4 text-amber-700 flex-shrink-0" />
                <div className="truncate">
                  <div className="font-black text-[11px]">CSC Cyber Cafe</div>
                  <div className="text-[9px] text-slate-600">VLE Portal</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('shopkeeper')}
                className="bg-orange-100 hover:bg-orange-200 text-slate-950 font-bold p-2.5 rounded-xl border border-orange-300 text-xs text-left transition flex items-center gap-1.5 shadow-sm"
              >
                <Store className="w-4 h-4 text-orange-700 flex-shrink-0" />
                <div className="truncate">
                  <div className="font-black text-[11px]">দোকানদার</div>
                  <div className="text-[9px] text-slate-600">Online Store</div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('admin')}
                className="bg-purple-100 hover:bg-purple-200 text-purple-950 font-bold p-2.5 rounded-xl border border-purple-300 text-xs text-left transition flex items-center gap-1.5 shadow-sm"
              >
                <Crown className="w-4 h-4 text-purple-700 flex-shrink-0" />
                <div className="truncate">
                  <div className="font-black text-[11px]">পোর্টাল ওনার</div>
                  <div className="text-[9px] text-purple-700">Master Admin</div>
                </div>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
