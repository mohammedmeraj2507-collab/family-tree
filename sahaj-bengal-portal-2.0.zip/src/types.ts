export interface BeneficiaryMember {
  id: number;
  memberLabel: string;
  aadharNo: string;
  applicantName: string;
  rationCardNo: string;
  category: 'AAY' | 'SPHH' | 'PHH' | 'RKSY-1' | 'RKSY-2' | 'GEN' | '';
  aadharLinkedMobile: string;
  gender: 'M' | 'F' | 'O' | '';
  dob: string;
  panNumber: string;
  epicNumber: string;
  acNumber: string;
  partNumber: string;
  serialNumber: string;
}

export interface FamilyDetails {
  fullAddress: string;
  district: string;
  blockUlb: string;
  gramPanchayatWard: string;
  familyHeadName: string;
  totalFamilyMembers: number;
  ssUrnNo: string;
  beneficiaryNameContact: string;
  beneficiarySignature: string;
  formDate: string;
}

export interface OfficialUseDetails {
  receivingAuthorityName: string;
  receivingAuthoritySignature: string;
}

export interface SwasthyaBimaFormData {
  formDate: string;
  members: BeneficiaryMember[];
  familyDetails: FamilyDetails;
  officialUse: OfficialUseDetails; // Must remain blank for official use as per user instruction
}

export interface FormSubmissionRecord {
  id: string;
  schemeId: string;
  schemeTitle: string;
  applicantName: string;
  aadharNo: string;
  mobileNo: string;
  totalMembers: number;
  submittedAt: string;
  charge: number;
  formData: SwasthyaBimaFormData | any;
}

export interface SchemeInfo {
  id: string;
  title: string;
  bengaliTitle: string;
  subtitle: string;
  description: string;
  badge: string;
  state: string;
  charge: number;
  status: 'active' | 'upcoming';
  image: string;
  category: string;
  totalPages: number;
  customFields?: any[];
}

export type UserRole = 'admin' | 'cyber_cafe' | 'shopkeeper' | 'citizen';

export interface CyberCafeProfile {
  cafeName: string;
  operatorName: string;
  phone: string;
  location: string;
  walletBalance: number;
  cscId?: string;
  email?: string;
  userType?: 'cyber_cafe' | 'shopkeeper' | 'citizen' | 'admin';
  userRole?: UserRole;
  isLoggedIn?: boolean;
}

export interface UserAccount {
  id: string;
  accountType: 'cyber_cafe' | 'shopkeeper' | 'citizen' | 'admin';
  fullName: string;
  cafeName?: string;
  cscId?: string;
  phone: string;
  email?: string;
  district: string;
  block?: string;
  walletBalance: number;
  isVerified: boolean;
}
