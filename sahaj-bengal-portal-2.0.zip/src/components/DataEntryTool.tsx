import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Download, 
  Eye, 
  RotateCcw, 
  Users, 
  Home, 
  Lock, 
  CheckCircle2, 
  Zap, 
  Copy, 
  Calendar, 
  User, 
  CreditCard, 
  Phone, 
  Sparkles, 
  Vote,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import { SwasthyaBimaFormData, BeneficiaryMember, SchemeInfo } from '../types';
import { 
  getInitialFormData, 
  SAMPLE_TEST_DATA, 
  WEST_BENGAL_DISTRICTS, 
  createEmptyMember 
} from '../utils/sampleData';

interface DataEntryToolProps {
  scheme: SchemeInfo;
  formData: SwasthyaBimaFormData;
  setFormData: React.Dispatch<React.SetStateAction<SwasthyaBimaFormData>>;
  onBack: () => void;
  onPreviewPDF: () => void;
  onSubmitAndDownload: () => void;
  lang: 'bn' | 'en';
  themeMode?: 'light' | 'dark';
}

export const DataEntryTool: React.FC<DataEntryToolProps> = ({
  scheme,
  formData,
  setFormData,
  onBack,
  onPreviewPDF,
  onSubmitAndDownload,
  lang,
}) => {
  const [activeMemberTab, setActiveMemberTab] = useState<number>(1);
  const [currentStep, setCurrentStep] = useState<'members' | 'family'>('members');

  // Update specific member field
  const updateMember = (
    index: number,
    field: keyof BeneficiaryMember,
    value: any
  ) => {
    setFormData((prev) => {
      const updatedMembers = [...prev.members];
      while (updatedMembers.length <= index) {
        updatedMembers.push(createEmptyMember(updatedMembers.length + 1));
      }
      updatedMembers[index] = {
        ...updatedMembers[index],
        [field]: value,
      };
      return {
        ...prev,
        members: updatedMembers,
      };
    });
  };

  // Format Aadhar with spaces
  const handleAadharChange = (index: number, rawVal: string) => {
    const digits = rawVal.replace(/\D/g, '').slice(0, 12);
    const formatted = digits.replace(/(\d{4})(?=\d)/g, '$1 ');
    updateMember(index, 'aadharNo', formatted);
  };

  // Format Mobile
  const handleMobileChange = (index: number, rawVal: string) => {
    const digits = rawVal.replace(/\D/g, '').slice(0, 10);
    updateMember(index, 'aadharLinkedMobile', digits);
  };

  // Format Ration Card
  const handleRationChange = (index: number, rawVal: string) => {
    updateMember(index, 'rationCardNo', rawVal.toUpperCase());
  };

  // Format PAN
  const handlePanChange = (index: number, rawVal: string) => {
    updateMember(index, 'panNumber', rawVal.toUpperCase().slice(0, 10));
  };

  // Format EPIC
  const handleEpicChange = (index: number, rawVal: string) => {
    updateMember(index, 'epicNumber', rawVal.toUpperCase());
  };

  // Quick auto-populate from Member 1 to Family Head on Page 3
  const handleCopyMember1ToFamily = () => {
    const m1 = formData.members[0];
    if (!m1 || !m1.applicantName) {
      alert(lang === 'bn' ? 'অনুগ্রহ করে প্রথমে সদস্য ১ এর নাম পূরণ করুন।' : 'Please enter Member 1 name first.');
      return;
    }
    setFormData((prev) => ({
      ...prev,
      familyDetails: {
        ...prev.familyDetails,
        familyHeadName: m1.applicantName,
        beneficiaryNameContact: `${m1.applicantName}${m1.aadharLinkedMobile ? ', Mob: ' + m1.aadharLinkedMobile : ''}`,
        beneficiarySignature: m1.applicantName,
      },
    }));
  };

  const handleLoadSample = () => {
    setFormData(JSON.parse(JSON.stringify(SAMPLE_TEST_DATA)));
  };

  const handleResetForm = () => {
    if (window.confirm(lang === 'bn' ? 'আপনি কি নিশ্চিত যে সমস্ত ফর্ম ডাটা রিসেট করতে চান?' : 'Are you sure you want to reset all form fields?')) {
      setFormData(getInitialFormData());
      setActiveMemberTab(1);
    }
  };

  const activeMember = formData.members[activeMemberTab - 1] || createEmptyMember(activeMemberTab);

  // Check how many members have names entered
  const filledMembersCount = formData.members.filter((m) => m.applicantName.trim() !== '').length;

  return (
    <div className="space-y-6 pb-16">
      {/* Top Header & Actions Bar (Clean White Background) */}
      <div className="bg-white border-2 border-amber-300 rounded-3xl p-4 sm:p-5 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 border-2 border-amber-300 text-slate-800 hover:text-slate-950 transition shadow-sm"
            title="Back to Dashboard"
          >
            <ArrowLeft className="w-5 h-5 text-amber-700" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black px-3 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300">
                {lang === 'bn' ? '৩-পেজ ডাটা এন্ট্রি ফরম' : '3-Page Official Form'}
              </span>
              <span className="text-xs font-mono font-bold text-slate-600">DATE: {formData.formDate}</span>
            </div>
            <h2 className="text-base sm:text-lg font-black text-slate-950 tracking-tight mt-0.5">
              {scheme.title}
            </h2>
          </div>
        </div>

        {/* Quick Utility Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleLoadSample}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-950 border-2 border-indigo-200 text-xs font-extrabold transition shadow-sm"
          >
            <Zap className="w-3.5 h-3.5 text-indigo-600" />
            <span>{lang === 'bn' ? 'স্যাম্পল ডাটা লোড' : 'Load Sample Data'}</span>
          </button>

          <button
            onClick={handleResetForm}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border-2 border-slate-300 text-xs font-extrabold transition shadow-sm"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-600" />
            <span>{lang === 'bn' ? 'রিসেট' : 'Reset'}</span>
          </button>

          <button
            onClick={onPreviewPDF}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-950 border-2 border-amber-300 text-xs font-extrabold transition shadow-sm"
          >
            <Eye className="w-3.5 h-3.5 text-amber-700" />
            <span>{lang === 'bn' ? 'লাইভ প্রিভিউ' : 'Live Preview'}</span>
          </button>

          <button
            onClick={onSubmitAndDownload}
            className="inline-flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white px-5 py-2.5 rounded-xl text-xs sm:text-sm font-black shadow-lg shadow-emerald-700/20 transition active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>{lang === 'bn' ? 'ডাউনলোড PDF (₹10)' : 'Download PDF (₹10)'}</span>
          </button>
        </div>
      </div>

      {/* Main Steps Switcher (Solid White & Bright Contrast) */}
      <div className="grid grid-cols-2 gap-3 p-1.5 bg-white border-2 border-amber-300 rounded-2xl shadow-md">
        <button
          onClick={() => setCurrentStep('members')}
          className={`py-3 px-4 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition ${
            currentStep === 'members'
              ? 'bg-amber-500 text-slate-950 shadow-md border-2 border-amber-600'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{lang === 'bn' ? '১ ও ২য় পৃষ্ঠা: সদস্য তথ্য (Members 1-6)' : 'Page 1 & 2: Member Details (1-6)'}</span>
          <span className="text-xs px-2.5 py-0.5 rounded-full font-black bg-white text-slate-900 border border-slate-300">
            {filledMembersCount} {lang === 'bn' ? 'পূরণ' : 'Filled'}
          </span>
        </button>

        <button
          onClick={() => setCurrentStep('family')}
          className={`py-3 px-4 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition ${
            currentStep === 'family'
              ? 'bg-amber-500 text-slate-950 shadow-md border-2 border-amber-600'
              : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Home className="w-4 h-4" />
          <span>{lang === 'bn' ? '৩য় পৃষ্ঠা: পারিবারিক তথ্য ও ঠিকানা' : 'Page 3: Family Details & Address'}</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* SECTION 1: BENEFICIARY MEMBERS (PAGES 1 & 2) */}
      {/* ========================================================================= */}
      {currentStep === 'members' && (
        <div className="space-y-6">
          {/* Member Tabs Pill Navigation (1 to 6) - Pure White Container */}
          <div className="bg-white border-2 border-amber-200/90 rounded-3xl p-4 sm:p-5 shadow-lg">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs font-black text-slate-900 uppercase tracking-wider">
                {lang === 'bn' ? 'সদস্য ট্যাব নির্বাচন করুন (১-৬)' : 'Select Member Tab (1 to 6)'}
              </div>
              <div className="text-xs font-bold text-amber-800 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                {lang === 'bn' ? 'পৃষ্ঠা ১ (সদস্য ১-৩) | পৃষ্ঠা ২ (সদস্য ৪-৬)' : 'Page 1 (M 1-3) | Page 2 (M 4-6)'}
              </div>
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5 sm:gap-3">
              {[1, 2, 3, 4, 5, 6].map((num) => {
                const mem = formData.members[num - 1];
                const isFilled = mem && mem.applicantName.trim() !== '';
                const isActive = activeMemberTab === num;

                return (
                  <button
                    key={num}
                    onClick={() => setActiveMemberTab(num)}
                    className={`p-3 rounded-2xl text-left border-2 transition relative flex flex-col justify-between shadow-sm ${
                      isActive
                        ? 'bg-amber-500 border-amber-600 text-slate-950 ring-2 ring-amber-400 font-black shadow-md'
                        : isFilled
                        ? 'bg-emerald-50 hover:bg-emerald-100 border-emerald-300 text-slate-900'
                        : 'bg-slate-50 hover:bg-slate-100 border-dashed border-slate-300 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-extrabold text-xs">
                        {num === 1 ? (lang === 'bn' ? 'সদস্য ১ (প্রধান)' : 'Member 1 (Head)') : `Member ${num}`}
                      </span>
                      {isFilled ? (
                        <CheckCircle2 className={`w-4 h-4 ${isActive ? 'text-slate-950' : 'text-emerald-600'}`} />
                      ) : (
                        <span className="w-2.5 h-2.5 rounded-full bg-slate-300"></span>
                      )}
                    </div>
                    <div className={`text-[11px] font-bold truncate mt-1 ${isActive ? 'text-slate-950' : isFilled ? 'text-slate-900' : 'text-slate-400'}`}>
                      {mem?.applicantName || (lang === 'bn' ? '(ফাঁকা)' : '(Empty)')}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Member Data Entry Card (PURE CRISP WHITE) */}
          <div className="bg-white border-2 border-slate-300 rounded-3xl p-6 sm:p-8 shadow-xl">
            {/* Member Title & Quick Copy Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b-2 border-slate-100 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-amber-500 text-slate-950 font-black text-xl flex items-center justify-center shadow-md">
                  {activeMemberTab}
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-950">
                    BASIC BENEFICIARY DETAILS (Member {activeMemberTab})
                  </h3>
                  <p className="text-xs font-bold text-slate-500">
                    {activeMemberTab <= 3 
                      ? (lang === 'bn' ? 'এই তথ্যটি পিডিএফ এর ১ম পৃষ্ঠায় মুদ্রিত হবে' : 'This section appears on Page 1 of the official PDF')
                      : (lang === 'bn' ? 'এই তথ্যটি পিডিএফ এর ২য় পৃষ্ঠায় মুদ্রিত হবে' : 'This section appears on Page 2 of the official PDF')}
                  </p>
                </div>
              </div>

              {/* Quick helper buttons */}
              {activeMemberTab > 1 && (
                <button
                  onClick={() => {
                    const m1 = formData.members[0];
                    if (m1) {
                      updateMember(activeMemberTab - 1, 'aadharLinkedMobile', m1.aadharLinkedMobile);
                      updateMember(activeMemberTab - 1, 'category', m1.category);
                      updateMember(activeMemberTab - 1, 'acNumber', m1.acNumber);
                      updateMember(activeMemberTab - 1, 'partNumber', m1.partNumber);
                    }
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-extrabold text-indigo-950 bg-indigo-50 hover:bg-indigo-100 px-3.5 py-2 rounded-xl border-2 border-indigo-200 shadow-sm transition"
                >
                  <Copy className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{lang === 'bn' ? 'সদস্য ১ থেকে মোবাইল/ক্যাটাগরি কপি করুন' : 'Copy Common Details from Member 1'}</span>
                </button>
              )}
            </div>

            {/* Main Form Fields Grid (PURE WHITE INPUTS WITH STRONG BORDERS) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* 1. Aadhar No */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  Aadhar No <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    value={activeMember.aadharNo}
                    onChange={(e) => handleAadharChange(activeMemberTab - 1, e.target.value)}
                    placeholder="1234 5678 9012"
                    maxLength={14}
                    className="w-full bg-white border-2 border-slate-300 rounded-xl pl-10 pr-4 py-2.5 text-sm font-mono font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                  />
                </div>
              </div>

              {/* 2. Applicant Name */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  Applicant Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    value={activeMember.applicantName}
                    onChange={(e) => updateMember(activeMemberTab - 1, 'applicantName', e.target.value.toUpperCase())}
                    placeholder={lang === 'bn' ? 'নাম লিখুন (যেমন: SUBRATA MUKHERJEE)' : 'Full Name in Capital Letters'}
                    className="w-full bg-white border-2 border-slate-300 rounded-xl pl-10 pr-4 py-2.5 text-sm font-black text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                  />
                </div>
              </div>

              {/* 3. Ration Card No */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  Ration Card No.
                </label>
                <input
                  type="text"
                  value={activeMember.rationCardNo}
                  onChange={(e) => handleRationChange(activeMemberTab - 1, e.target.value)}
                  placeholder="RC-WB-1234567"
                  className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                />
              </div>

              {/* 4. Category */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  Category (AAY/SPHH/PHH/RKSY-1/RKSY-2/GEN)
                </label>
                <select
                  value={activeMember.category}
                  onChange={(e) => updateMember(activeMemberTab - 1, 'category', e.target.value as any)}
                  className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-950 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                >
                  <option value="">-- {lang === 'bn' ? 'ক্যাটাগরি নির্বাচন করুন' : 'Select Category'} --</option>
                  <option value="AAY">AAY (Antyodaya Anna Yojana)</option>
                  <option value="SPHH">SPHH (State Priority Ration Card)</option>
                  <option value="PHH">PHH (Priority Household)</option>
                  <option value="RKSY-1">RKSY-1 (Rajya Khadya Suraksha 1)</option>
                  <option value="RKSY-2">RKSY-2 (Rajya Khadya Suraksha 2)</option>
                  <option value="GEN">GEN (General Category)</option>
                </select>
              </div>

              {/* 5. Aadhar Linked Mobile */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  Aadhar Linked Mobile
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="tel"
                    value={activeMember.aadharLinkedMobile}
                    onChange={(e) => handleMobileChange(activeMemberTab - 1, e.target.value)}
                    placeholder="9830123456"
                    maxLength={10}
                    className="w-full bg-white border-2 border-slate-300 rounded-xl pl-10 pr-4 py-2.5 text-sm font-mono font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                  />
                </div>
              </div>

              {/* 6. Gender */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  Gender (M/F/O)
                </label>
                <select
                  value={activeMember.gender}
                  onChange={(e) => updateMember(activeMemberTab - 1, 'gender', e.target.value as any)}
                  className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-950 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                >
                  <option value="">-- {lang === 'bn' ? 'লিঙ্গ নির্বাচন করুন' : 'Select Gender'} --</option>
                  <option value="M">M (Male / পুরুষ)</option>
                  <option value="F">F (Female / মহিলা)</option>
                  <option value="O">O (Other / অন্যান্য)</option>
                </select>
              </div>

              {/* 7. Date of Birth */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  Date of Birth (DD/MM/YYYY)
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    value={activeMember.dob}
                    onChange={(e) => updateMember(activeMemberTab - 1, 'dob', e.target.value)}
                    placeholder="15/04/1985"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl pl-10 pr-4 py-2.5 text-sm font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                  />
                </div>
              </div>

              {/* 8. PAN Number */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  PAN Number
                </label>
                <input
                  type="text"
                  value={activeMember.panNumber}
                  onChange={(e) => handlePanChange(activeMemberTab - 1, e.target.value)}
                  placeholder="ABCDE1234F"
                  maxLength={10}
                  className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-mono font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                />
              </div>
            </div>

            {/* Sub-Card: ELECTORAL DETAILS (Clear White Background & Distinct Borders) */}
            <div className="mt-8 pt-6 border-t-2 border-slate-100">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold">
                  <Vote className="w-4 h-4" />
                </div>
                <h4 className="text-sm font-black text-slate-950 uppercase tracking-wider">
                  ELECTORAL DETAILS (ভোটার সংক্রান্ত তথ্য)
                </h4>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {/* EPIC Number */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    EPIC Number (Voter ID)
                  </label>
                  <input
                    type="text"
                    value={activeMember.epicNumber}
                    onChange={(e) => handleEpicChange(activeMemberTab - 1, e.target.value)}
                    placeholder="WB/14/098/54321"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-3.5 py-2 text-xs font-mono font-bold text-slate-950 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>

                {/* AC Number */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    AC Number (Assembly)
                  </label>
                  <input
                    type="text"
                    value={activeMember.acNumber}
                    onChange={(e) => updateMember(activeMemberTab - 1, 'acNumber', e.target.value)}
                    placeholder="115"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-3.5 py-2 text-xs font-bold text-slate-950 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>

                {/* PART Number */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    PART Number
                  </label>
                  <input
                    type="text"
                    value={activeMember.partNumber}
                    onChange={(e) => updateMember(activeMemberTab - 1, 'partNumber', e.target.value)}
                    placeholder="42"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-3.5 py-2 text-xs font-bold text-slate-950 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>

                {/* Serial Number */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Serial Number
                  </label>
                  <input
                    type="text"
                    value={activeMember.serialNumber}
                    onChange={(e) => updateMember(activeMemberTab - 1, 'serialNumber', e.target.value)}
                    placeholder="108"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-3.5 py-2 text-xs font-bold text-slate-950 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>
              </div>
            </div>

            {/* Member Tab Next / Previous Buttons */}
            <div className="mt-8 pt-5 border-t-2 border-slate-100 flex items-center justify-between">
              <button
                type="button"
                disabled={activeMemberTab === 1}
                onClick={() => setActiveMemberTab((p) => Math.max(1, p - 1))}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-800 border-2 border-slate-300 disabled:opacity-40 transition shadow-sm"
              >
                ← {lang === 'bn' ? 'পূর্ববর্তী সদস্য' : 'Previous Member'}
              </button>

              <div className="flex items-center gap-2">
                {activeMemberTab < 6 ? (
                  <button
                    type="button"
                    onClick={() => setActiveMemberTab((p) => Math.min(6, p + 1))}
                    className="px-5 py-2.5 rounded-xl text-xs font-black bg-amber-500 hover:bg-amber-400 text-slate-950 transition flex items-center gap-1 shadow-md"
                  >
                    <span>{lang === 'bn' ? `পরবর্তী সদস্য (${activeMemberTab + 1})` : `Next Member (${activeMemberTab + 1})`}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setCurrentStep('family')}
                    className="px-5 py-2.5 rounded-xl text-xs font-black bg-indigo-600 hover:bg-indigo-500 text-white transition flex items-center gap-1 shadow-md"
                  >
                    <span>{lang === 'bn' ? '৩য় পৃষ্ঠা: পারিবারিক তথ্যে যান' : 'Go to Page 3: Family Details'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION 2: FAMILY DETAILS & ADDRESS (PAGE 3) */}
      {/* ========================================================================= */}
      {currentStep === 'family' && (
        <div className="space-y-6">
          <div className="bg-white border-2 border-slate-300 rounded-3xl p-6 sm:p-8 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b-2 border-slate-100 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shadow-md">
                  <Home className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-950">
                    Family Details & Address (৩য় পৃষ্ঠা)
                  </h3>
                  <p className="text-xs font-bold text-slate-500">
                    {lang === 'bn' ? 'আবেদনকারীর পূর্ণ ঠিকানা ও পারিবারিক বিবরণ' : 'Full address and household particulars for Page 3'}
                  </p>
                </div>
              </div>

              <button
                onClick={handleCopyMember1ToFamily}
                className="inline-flex items-center gap-1.5 text-xs font-black text-emerald-950 bg-emerald-100 hover:bg-emerald-200 px-4 py-2 rounded-xl border-2 border-emerald-300 transition shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-emerald-700" />
                <span>{lang === 'bn' ? 'সদস্য ১ এর নাম দিয়ে অটো-সিঙ্ক করুন' : 'Auto-Sync from Member 1'}</span>
              </button>
            </div>

            <div className="space-y-5">
              {/* Full Address Row */}
              <div>
                <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                  FULL ADDRESS (HOUSE NO. / STREET / VILLAGE / WARD) <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={2}
                  value={formData.familyDetails.fullAddress}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      familyDetails: { ...prev.familyDetails, fullAddress: e.target.value },
                    }))
                  }
                  placeholder={lang === 'bn' ? 'যেমন: Vill - Nabapally, PO - Barasat, PS - Barasat, Pin - 700126' : 'House No, Village/Street, Post Office, Police Station, PIN Code'}
                  className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 transition shadow-sm"
                />
              </div>

              {/* District & Block */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                    DISTRICT (জেলা) <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={formData.familyDetails.district}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        familyDetails: { ...prev.familyDetails, district: e.target.value },
                      }))
                    }
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-950 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  >
                    {WEST_BENGAL_DISTRICTS.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                    BLOCK/ULB (ব্লক / পৌরসভা) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.familyDetails.blockUlb}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        familyDetails: { ...prev.familyDetails, blockUlb: e.target.value.toUpperCase() },
                      }))
                    }
                    placeholder="BARASAT-I BLOCK / MUNICIPALITY"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>
              </div>

              {/* GP/Ward & Family Head Name */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                    GRAM PANCHAYAT / WARD
                  </label>
                  <input
                    type="text"
                    value={formData.familyDetails.gramPanchayatWard}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        familyDetails: { ...prev.familyDetails, gramPanchayatWard: e.target.value.toUpperCase() },
                      }))
                    }
                    placeholder="WARD NO 14 / KADAMBAGACHI GP"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                    FAMILY HEAD NAME <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.familyDetails.familyHeadName}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        familyDetails: { ...prev.familyDetails, familyHeadName: e.target.value.toUpperCase() },
                      }))
                    }
                    placeholder="SUBRATA MUKHERJEE"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-black text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>
              </div>

              {/* Total Members & SS URN */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                    TOTAL FAMILY MEMBERS (মোট সদস্য)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={formData.familyDetails.totalFamilyMembers}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        familyDetails: { ...prev.familyDetails, totalFamilyMembers: parseInt(e.target.value) || 1 },
                      }))
                    }
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-black text-slate-950 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                    SS URN NO. (17-DIGIT)
                  </label>
                  <input
                    type="text"
                    maxLength={17}
                    value={formData.familyDetails.ssUrnNo}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        familyDetails: { ...prev.familyDetails, ssUrnNo: e.target.value.replace(/\D/g, '') },
                      }))
                    }
                    placeholder="19041285093847291"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-mono font-black text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>
              </div>

              {/* Beneficiary Name & Signature */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                    NAME and CONTACT NUMBER OF BENEFICIARY
                  </label>
                  <input
                    type="text"
                    value={formData.familyDetails.beneficiaryNameContact}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        familyDetails: { ...prev.familyDetails, beneficiaryNameContact: e.target.value },
                      }))
                    }
                    placeholder="SUBRATA MUKHERJEE, Mob: 9830123456"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm font-bold text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-black text-slate-900 uppercase tracking-wider mb-1.5">
                    SIGNATURE OF THE BENEFICIARY (স্বাক্ষর)
                  </label>
                  <input
                    type="text"
                    value={formData.familyDetails.beneficiarySignature}
                    onChange={(e) =>
                      setFormData((prev) => ({
                        ...prev,
                        familyDetails: { ...prev.familyDetails, beneficiarySignature: e.target.value },
                      }))
                    }
                    placeholder="Subrata Mukherjee"
                    className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2.5 text-sm italic font-black text-slate-950 placeholder-slate-400 focus:border-amber-500 focus:ring-2 focus:ring-amber-200 shadow-sm"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* CRITICAL: OFFICIAL USE LOCK CARD (MANDATORY REQUIREMENT) */}
          <div className="bg-amber-50 border-2 border-dashed border-amber-400 p-6 rounded-3xl shadow-md">
            <div className="flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center flex-shrink-0 shadow-md">
                <Lock className="w-5 h-5" />
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="bg-amber-500 text-slate-950 text-xs font-black px-3 py-0.5 rounded-full uppercase shadow-sm">
                    {lang === 'bn' ? 'অফিসিয়াল ব্যবহার এলাকা' : 'Official Use Area'}
                  </span>
                  <span className="text-xs font-black text-amber-900">
                    {lang === 'bn' ? 'লকড / সম্পূর্ণ ফাঁকা থাকবে' : 'LOCKED - KEPT STRICTLY BLANK'}
                  </span>
                </div>

                <h4 className="text-sm font-black text-slate-950">
                  Receiving Authority Name, Designation, Contact Number & Signature
                </h4>

                <p className="text-xs text-slate-700 font-medium leading-relaxed">
                  {lang === 'bn'
                    ? '⚠️ গুরুত্বপূর্ণ নির্দেশনা: আপনার নির্দেশিকা অনুযায়ী, সাইবার ক্যাফে বা আবেদনকারী শুধুমাত্র গ্রাহক তথ্য পূরণ করবেন। সরকারি আধিকারিক (Receiving Authority) এর নাম, পদবি এবং স্বাক্ষরের জায়গাটি পিডিএফ এ হুবহু ফাঁকা রেখে প্রিন্ট হবে।'
                    : '⚠️ Important Instruction: As instructed, Cyber Cafe operators only fill applicant/customer details. Official Receiving Authority fields and signature remain completely blank for government officers.'}
                </p>

                <div className="mt-2 bg-white p-3.5 rounded-xl border-2 border-amber-200 text-slate-900 font-mono text-xs space-y-1 shadow-sm">
                  <div>• Receiving Authority Name, Designation, Contact Number: <span className="text-amber-700 font-black">[ ফাঁকা থাকবে ]</span></div>
                  <div>• Receiving Authority Signature: <span className="text-amber-700 font-black">[ ফাঁকা থাকবে ]</span></div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Actions Bar */}
          <div className="flex items-center justify-between pt-4">
            <button
              onClick={() => setCurrentStep('members')}
              className="px-5 py-2.5 rounded-xl text-xs font-extrabold bg-white hover:bg-slate-100 text-slate-800 border-2 border-slate-300 transition flex items-center gap-1.5 shadow-sm"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{lang === 'bn' ? 'সদস্য তথ্যে ফিরে যান' : 'Back to Member Details'}</span>
            </button>

            <button
              onClick={onSubmitAndDownload}
              className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black px-7 py-3 rounded-xl shadow-lg shadow-emerald-700/25 flex items-center gap-2 transition active:scale-95 text-sm sm:text-base"
            >
              <Download className="w-5 h-5" />
              <span>{lang === 'bn' ? 'ফ্রম সাবমিট ও পিডিএফ ডাউনলোড (₹10)' : 'Submit & Download PDF (₹10)'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
