import React, { useState } from 'react';
  History, 
  Search, 
  Download, 
  Printer, 
  FileText, 
  Trash2, 
  CheckCircle2, 
  User, 
  Calendar, 
  ArrowLeft,
  Filter
} from 'lucide-react';
import { FormSubmissionRecord } from '../types';

interface HistoryViewProps {
  submissions: FormSubmissionRecord[];
  onDownloadRecord: (record: FormSubmissionRecord) => void;
  onPrintRecord: (record: FormSubmissionRecord) => void;
  onDeleteRecord: (id: string) => void;
  onBack: () => void;
  onOpenDataEntry: () => void;
  lang: 'bn' | 'en';
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  submissions,
  onDownloadRecord,
  onPrintRecord,
  onDeleteRecord,
  onBack,
  onOpenDataEntry,
  lang,
}) => {
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredSubmissions = submissions.filter((rec) => {
    const q = searchTerm.toLowerCase();
    return (
      (rec.applicantName && rec.applicantName.toLowerCase().includes(q)) ||
      (rec.aadharNo && rec.aadharNo.includes(q)) ||
      (rec.mobileNo && rec.mobileNo.includes(q)) ||
      (rec.schemeTitle && rec.schemeTitle.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <History className="w-5 h-5 text-indigo-500" />
              {lang === 'bn' ? 'আবেদন ও ডাউনলোড হিস্ট্রি' : 'Form Submission & Download Archive'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {lang === 'bn'
                ? 'সাইবার ক্যাফে থেকে তৈরি সকল আবেদনকারীর তথ্যের রেকর্ড'
                : 'Complete records of previously generated customer enrollment forms'}
            </p>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative min-w-[260px] flex-1 sm:flex-initial">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={lang === 'bn' ? 'নাম, আধার বা মোবাইল দিয়ে খুঁজুন...' : 'Search by name, aadhar or mobile...'}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl pl-10 pr-4 py-2 text-xs font-medium text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* Submissions List */}
      {filteredSubmissions.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center shadow">
          <FileText className="w-12 h-12 text-slate-400 mx-auto mb-3 opacity-40" />
          <h3 className="font-bold text-base text-slate-900 dark:text-white">
            {searchTerm 
              ? (lang === 'bn' ? 'কোনো ফলাফল পাওয়া যায়নি' : 'No matching records found') 
              : (lang === 'bn' ? 'এখনো কোনো ফর্ম সাবমিট করা হয়নি' : 'No form submissions yet')}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm mx-auto">
            {searchTerm 
              ? (lang === 'bn' ? 'অনুগ্রহ করে সঠিক নাম বা আধার নম্বর দিয়ে আবার চেষ্টা করুন।' : 'Try searching with a different name or number.')
              : (lang === 'bn' ? 'নতুন আবেদনকারীর ফর্ম এন্ট্রি করতে ডাটা এন্ট্রি শুরু করুন।' : 'Start your first beneficiary data entry.')}
          </p>
          {!searchTerm && (
            <button
              onClick={onOpenDataEntry}
              className="mt-4 inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow transition"
            >
              <FileText className="w-4 h-4" />
              <span>{lang === 'bn' ? 'ডাটা এন্ট্রি শুরু করুন' : 'Start Data Entry'}</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredSubmissions.map((rec) => (
            <div
              key={rec.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow hover:shadow-lg transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800 uppercase">
                      {rec.schemeTitle || 'SWSTHYA BIMA'}
                    </span>
                    <h4 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white mt-1.5 line-clamp-1">
                      {rec.applicantName || 'Unnamed Applicant'}
                    </h4>
                  </div>
                  <span className="text-xs font-bold text-emerald-500 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-lg">
                    ₹{rec.charge}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300 my-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">{lang === 'bn' ? 'আধার নম্বর:' : 'Aadhar:'}</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{rec.aadharNo || '—'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">{lang === 'bn' ? 'মোবাইল:' : 'Mobile:'}</span>
                    <span>{rec.mobileNo || '—'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">{lang === 'bn' ? 'মোট সদস্য:' : 'Members:'}</span>
                    <span className="font-bold">{rec.totalMembers} জন</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">{lang === 'bn' ? 'তারিখ ও সময়:' : 'Date:'}</span>
                    <span className="text-slate-500">{rec.submittedAt}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                <button
                  onClick={() => onDeleteRecord(rec.id)}
                  className="p-2 text-slate-400 hover:text-red-500 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  title="Delete Record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onPrintRecord(rec)}
                    className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 px-3 py-1.5 rounded-lg text-xs font-semibold transition"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>{lang === 'bn' ? 'প্রিন্ট' : 'Print'}</span>
                  </button>

                  <button
                    onClick={() => onDownloadRecord(rec)}
                    className="inline-flex items-center gap-1 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{lang === 'bn' ? 'পিডিএফ' : 'PDF'}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
