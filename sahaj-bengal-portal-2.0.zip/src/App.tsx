import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { DataEntryTool } from './components/DataEntryTool';
import { PDFPreviewModal } from './components/PDFPreviewModal';
import { FormScannerModal } from './components/FormScannerModal';
import { WalletModal } from './components/WalletModal';
import { UserAuthModal } from './components/UserAuthModal';
import { 
  SchemeInfo, 
  SwasthyaBimaFormData, 
  CyberCafeProfile 
} from './types';
import { 
  INITIAL_SCHEMES, 
  INITIAL_CAFE_PROFILE, 
  getInitialFormData, 
  SAMPLE_TEST_DATA 
} from './utils/sampleData';
import { generateSwasthyaBimaPDF } from './utils/pdfGenerator';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'data-entry' | 'scanner'>('dashboard');
  const [themeMode, setThemeMode] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('sahaj_portal_theme');
    return (saved === 'dark' || saved === 'light') ? saved : 'light';
  });

  const [schemes, setSchemes] = useState<SchemeInfo[]>(() => {
    const saved = localStorage.getItem('cyber_cafe_schemes');
    return saved ? JSON.parse(saved) : INITIAL_SCHEMES;
  });
  const [activeScheme, setActiveScheme] = useState<SchemeInfo>(() => schemes[0]);

  const [formData, setFormData] = useState<SwasthyaBimaFormData>(getInitialFormData);

  const [cafeProfile, setCafeProfile] = useState<CyberCafeProfile>(() => {
    const saved = localStorage.getItem('cyber_cafe_profile');
    return saved ? JSON.parse(saved) : INITIAL_CAFE_PROFILE;
  });

  const [lang, setLang] = useState<'bn' | 'en'>('bn');

  // Modals
  const [isPreviewOpen, setIsPreviewOpen] = useState<boolean>(false);
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isWalletOpen, setIsWalletOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [downloadSuccessNotice, setDownloadSuccessNotice] = useState<string | null>(null);

  // Clear legacy stored submissions to ensure 100% privacy
  useEffect(() => {
    localStorage.removeItem('cyber_cafe_submissions');
  }, []);

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('cyber_cafe_schemes', JSON.stringify(schemes));
  }, [schemes]);

  useEffect(() => {
    localStorage.setItem('cyber_cafe_profile', JSON.stringify(cafeProfile));
  }, [cafeProfile]);

  useEffect(() => {
    localStorage.setItem('sahaj_portal_theme', themeMode);
    if (themeMode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [themeMode]);

  const handleSelectScheme = (scheme: SchemeInfo) => {
    setActiveScheme(scheme);
    setCurrentTab('data-entry');
  };

  const handleOpenDataEntry = (autofillSample = false) => {
    if (autofillSample) {
      setFormData(JSON.parse(JSON.stringify(SAMPLE_TEST_DATA)));
    } else {
      setFormData(getInitialFormData());
    }
    setCurrentTab('data-entry');
  };

  const handleAddNewScheme = (newScheme: SchemeInfo) => {
    setSchemes((prev) => [newScheme, ...prev]);
    setActiveScheme(newScheme);
    setCurrentTab('data-entry');
  };

  const handleAddWalletBalance = (amount: number) => {
    setCafeProfile((prev) => ({
      ...prev,
      walletBalance: prev.walletBalance + amount,
    }));
  };

  const handleSaveProfile = (updated: CyberCafeProfile) => {
    setCafeProfile(updated);
  };

  const triggerDownloadPDF = async (dataToDownload: SwasthyaBimaFormData) => {
    // Check wallet balance
    const charge = 10;
    if (cafeProfile.walletBalance < charge) {
      alert(lang === 'bn' 
        ? `আপনার ওয়ালেট ব্যালেন্স কম (₹${cafeProfile.walletBalance})। ফর্ম ডাউনলোড করতে অনুগ্রহ করে রিচার্জ করুন (চার্জ ₹10)।` 
        : `Insufficient wallet balance (₹${cafeProfile.walletBalance}). Please recharge to download (Charge ₹10).`);
      setIsWalletOpen(true);
      return;
    }

    try {
      // 1. Generate pristine PDF
      const pdfBytes = await generateSwasthyaBimaPDF(dataToDownload);
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      // 2. Trigger browser download
      const link = document.createElement('a');
      link.href = url;
      const applicantName = dataToDownload.members[0]?.applicantName?.trim() || 'Beneficiary';
      const cleanName = applicantName.replace(/\s+/g, '_');
      link.download = `${cleanName}_Swasthya_Bima_WB_Form.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // 3. Deduct ₹10 wallet balance
      setCafeProfile((prev) => ({
        ...prev,
        walletBalance: Math.max(0, prev.walletBalance - charge),
      }));

      // 4. INSTANT CUSTOMER DATA WIPE (Zero retention requirement)
      setFormData(getInitialFormData());

      // 5. Celebration confetti
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 },
      });

      // 6. Success notice highlighting instant data wipe
      setDownloadSuccessNotice(
        lang === 'bn'
          ? `সফল! "${applicantName}" এর ৩-পেজ সরকারি ফর্ম ডাউনলোড হয়েছে এবং মেমোরি থেকে সমস্ত কাস্টমার ডেটা তৎক্ষণাৎ মুছে ফেলা হয়েছে।`
          : `Success! Form for "${applicantName}" downloaded. Customer data was instantly wiped from memory.`
      );

      setTimeout(() => {
        setDownloadSuccessNotice(null);
      }, 6000);
    } catch (err) {
      console.error('Error generating PDF:', err);
      alert('Error generating PDF. Please try again.');
    }
  };

  const isLight = themeMode === 'light';

  return (
    <div className={`min-h-screen font-sans selection:bg-amber-500 selection:text-slate-950 relative overflow-hidden transition-colors duration-300 ${isLight ? 'bg-[#fcfaf6] text-slate-900' : 'bg-slate-950 text-slate-100'}`}>
      
      {/* Background Decorative Ambient Gradients */}
      {isLight ? (
        <>
          <div className="fixed inset-0 bg-radial-at-t from-amber-100/60 via-[#fcfaf6] to-[#f7f3ec] -z-20"></div>
          <div className="fixed inset-0 opacity-[0.03] bg-[linear-gradient(to_right,#d97706_1px,transparent_1px),linear-gradient(to_bottom,#d97706_1px,transparent_1px)] bg-[size:4rem_4rem] -z-15 pointer-events-none"></div>
          <div className="fixed top-[-10%] left-[-5%] w-[45vw] h-[45vw] rounded-full bg-amber-400/15 blur-[120px] pointer-events-none -z-10"></div>
          <div className="fixed bottom-[-10%] right-[-5%] w-[45vw] h-[45vw] rounded-full bg-orange-400/15 blur-[130px] pointer-events-none -z-10"></div>
        </>
      ) : (
        <>
          <div className="fixed inset-0 bg-radial-at-t from-slate-900 via-slate-950 to-slate-950 -z-20"></div>
          <div className="fixed inset-0 opacity-[0.03] bg-[linear-gradient(to_right,#ffffff_1px,transparent_1px),linear-gradient(to_bottom,#ffffff_1px,transparent_1px)] bg-[size:4rem_4rem] -z-15 pointer-events-none"></div>
          <div className="fixed top-[-10%] left-[-5%] w-[45vw] h-[45vw] rounded-full bg-amber-500/10 blur-[140px] pointer-events-none -z-10"></div>
          <div className="fixed bottom-[-10%] right-[-5%] w-[45vw] h-[45vw] rounded-full bg-orange-600/10 blur-[150px] pointer-events-none -z-10"></div>
        </>
      )}

      {/* Top Header & Navigation */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        cafeProfile={cafeProfile}
        onOpenWallet={() => setIsWalletOpen(true)}
        onOpenScanner={() => setIsScannerOpen(true)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        lang={lang}
        setLang={setLang}
        themeMode={themeMode}
        setThemeMode={setThemeMode}
      />

      {/* Floating Success Banner */}
      {downloadSuccessNotice && (
        <div className="max-w-4xl mx-auto px-4 sm:px-6 mt-4">
          <div className={`backdrop-blur-xl border px-4 py-3 rounded-2xl shadow-xl flex items-center justify-between text-xs sm:text-sm font-bold animate-in slide-in-from-top duration-300 ${isLight ? 'bg-emerald-100/90 border-emerald-300 text-emerald-950' : 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200 shadow-emerald-950/70'}`}>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              <span>{downloadSuccessNotice}</span>
            </div>
            <button
              onClick={() => setDownloadSuccessNotice(null)}
              className={`ml-3 text-xs border px-2.5 py-1 rounded-lg transition ${isLight ? 'bg-emerald-200/80 hover:bg-emerald-300 text-emerald-900 border-emerald-400' : 'bg-emerald-500/30 hover:bg-emerald-500/50 text-emerald-300 border-emerald-400/30'}`}
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main View Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {currentTab === 'dashboard' && (
          <Dashboard
            schemes={schemes}
            cafeProfile={cafeProfile}
            onSelectScheme={handleSelectScheme}
            onOpenDataEntry={handleOpenDataEntry}
            onOpenPreviewTemplate={() => setIsPreviewOpen(true)}
            onOpenScanner={() => setIsScannerOpen(true)}
            onOpenAuth={() => setIsAuthModalOpen(true)}
            lang={lang}
            themeMode={themeMode}
          />
        )}

        {currentTab === 'data-entry' && (
          <DataEntryTool
            scheme={activeScheme}
            formData={formData}
            setFormData={setFormData}
            onBack={() => setCurrentTab('dashboard')}
            onPreviewPDF={() => setIsPreviewOpen(true)}
            onSubmitAndDownload={() => triggerDownloadPDF(formData)}
            lang={lang}
            themeMode={themeMode}
          />
        )}
      </main>

      {/* Modals */}
      <PDFPreviewModal
        isOpen={isPreviewOpen}
        onClose={() => setIsPreviewOpen(false)}
        formData={formData}
        scheme={activeScheme}
        onDownload={() => {
          setIsPreviewOpen(false);
          triggerDownloadPDF(formData);
        }}
        lang={lang}
      />

      <FormScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onAddNewScheme={handleAddNewScheme}
        lang={lang}
      />

      <WalletModal
        isOpen={isWalletOpen}
        onClose={() => setIsWalletOpen(false)}
        cafeProfile={cafeProfile}
        onAddBalance={handleAddWalletBalance}
        lang={lang}
      />

      <UserAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        cafeProfile={cafeProfile}
        onSaveProfile={handleSaveProfile}
        lang={lang}
      />
    </div>
  );
}
