import React, { useState } from 'react';
import { 
  FileCheck2, 
  ArrowRight, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  UploadCloud, 
  Layers, 
  CheckCircle, 
  Zap, 
  Eye, 
  IndianRupee, 
  Lock, 
  Trash2, 
  CheckCircle2, 
  LogIn, 
  UserPlus, 
  Building2, 
  UserCheck,
  Store,
  Crown,
  Wallet,
  Users,
  Search,
  PlusCircle,
  Activity,
  Check,
  Smartphone
} from 'lucide-react';
import cybercafeBg from '../assets/images/cybercafe_bg_1787845442322.jpg';
import { SchemeInfo, CyberCafeProfile } from '../types';
import { SahajBengalLogo } from './SahajBengalLogo';

interface DashboardProps {
  schemes: SchemeInfo[];
  cafeProfile: CyberCafeProfile;
  onSelectScheme: (scheme: SchemeInfo) => void;
  onOpenDataEntry: (autofillSample?: boolean) => void;
  onOpenPreviewTemplate: () => void;
  onOpenScanner: () => void;
  onOpenWallet?: () => void;
  onOpenAuth?: () => void;
  lang: 'bn' | 'en';
  themeMode?: 'light' | 'dark';
}

export const Dashboard: React.FC<DashboardProps> = ({
  schemes,
  cafeProfile,
  onSelectScheme,
  onOpenDataEntry,
  onOpenPreviewTemplate,
  onOpenScanner,
  onOpenWallet,
  onOpenAuth,
  lang,
  themeMode = 'light',
}) => {
  const isLight = themeMode === 'light';
  const isAdmin = cafeProfile.userType === 'admin';
  const [adminViewMode, setAdminViewMode] = useState<'admin_panel' | 'user_preview'>(isAdmin ? 'admin_panel' : 'user_preview');
  
  // Sample Cyber Cafe & Shopkeeper directory for Admin Management
  const [shopsList, setShopsList] = useState([
    { id: '1', name: 'Maa Tara Online Digital Corner', owner: 'Subir Roy', type: 'দোকানদার', phone: '9832145678', district: 'Hooghly', balance: 650, status: 'Active' },
    { id: '2', name: 'Bengal Digital Seva Kendra (CSC)', owner: 'Ramesh Sen (VLE)', type: 'সাইবার ক্যাফে', phone: '9830012345', district: 'North 24 Pgs', balance: 500, status: 'Active' },
    { id: '3', name: 'Biswas Cyber Cafe & Xerox', owner: 'Pritam Biswas', type: 'সাইবার ক্যাফে', phone: '9832299881', district: 'Nadia', balance: 320, status: 'Active' },
    { id: '4', name: 'Gramin Digital Seva Shop', owner: 'Manish Das', type: 'দোকানদার', phone: '9733451290', district: 'Murshidabad', balance: 180, status: 'Active' },
    { id: '5', name: 'Ananya Personal User', owner: 'Ananya Mukherjee', type: 'নাগরিক', phone: '9874561230', district: 'South 24 Pgs', balance: 200, status: 'Active' },
  ]);
  const [searchTerm, setSearchTerm] = useState('');
  const [creditNotice, setCreditNotice] = useState<string | null>(null);

  const activeScheme = schemes.find((s) => s.status === 'active') || schemes[0];

  const handleAdminCreditBalance = (shopId: string, amount: number) => {
    setShopsList(prev => prev.map(s => s.id === shopId ? { ...s, balance: s.balance + amount } : s));
    const target = shopsList.find(s => s.id === shopId);
    setCreditNotice(`₹${amount} ব্যালেন্স সফলভাবে ${target?.name} এ যুক্ত করা হয়েছে!`);
    setTimeout(() => setCreditNotice(null), 3000);
  };

  const filteredShops = shopsList.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.owner.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.phone.includes(searchTerm) ||
    s.district.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-12">
      
      {/* ========================================================================= */}
      {/* ADMIN EXCLUSIVE CONTROLS (IF LOGGED IN AS OWNER/ADMIN) */}
      {/* ========================================================================= */}
      {isAdmin && (
        <div className="bg-purple-950/90 text-white border-2 border-purple-400/80 rounded-3xl p-5 sm:p-6 shadow-2xl shadow-purple-950/40">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-purple-800">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-purple-600 border border-purple-400 flex items-center justify-center text-white shadow-lg">
                <Crown className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="bg-purple-500/40 text-purple-200 text-xs font-black px-2.5 py-0.5 rounded-full border border-purple-400">
                    MASTER OWNER ACCESS
                  </span>
                  <span className="text-xs text-purple-300 font-mono">ID: SAHAJ-ADMIN-01</span>
                </div>
                <h3 className="text-lg sm:text-xl font-black text-white">
                  মাস্টার ওনার অ্যাডমিন ড্যাশবোর্ড (আমার ব্যক্তিগত কন্ট্রোল প্যানেল)
                </h3>
              </div>
            </div>

            {/* View Switcher for Owner */}
            <div className="flex items-center gap-2 bg-purple-900/80 p-1 rounded-2xl border border-purple-700">
              <button
                onClick={() => setAdminViewMode('admin_panel')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition ${
                  adminViewMode === 'admin_panel' ? 'bg-purple-600 text-white shadow-md' : 'text-purple-300 hover:text-white'
                }`}
              >
                👑 মাস্টার অ্যাডমিন ভিউ
              </button>
              <button
                onClick={() => setAdminViewMode('user_preview')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition ${
                  adminViewMode === 'user_preview' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-purple-300 hover:text-white'
                }`}
              >
                👤 দোকানদার / ইউজার ভিউ দেখুন
              </button>
            </div>
          </div>

          {/* Master Telemetry Cards */}
          {adminViewMode === 'admin_panel' && (
            <div className="mt-5 space-y-6">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
                <div className="bg-purple-900/60 border border-purple-700/60 p-4 rounded-2xl">
                  <div className="text-xs text-purple-300 font-bold">মোট সাইবার ক্যাফে ও দোকানদার</div>
                  <div className="text-2xl font-black text-white mt-1">164 টি দোকান</div>
                  <div className="text-[11px] text-emerald-400 font-semibold mt-0.5">+12 আজ যুক্ত হয়েছে</div>
                </div>

                <div className="bg-purple-900/60 border border-purple-700/60 p-4 rounded-2xl">
                  <div className="text-xs text-purple-300 font-bold">মোট ডাউনলোডকৃত PDF</div>
                  <div className="text-2xl font-black text-white mt-1">1,480 কপি</div>
                  <div className="text-[11px] text-emerald-400 font-semibold mt-0.5">স্বাস্থ্য বীমা ৩-পেজ</div>
                </div>

                <div className="bg-purple-900/60 border border-purple-700/60 p-4 rounded-2xl">
                  <div className="text-xs text-purple-300 font-bold">মোট প্ল্যাটফর্ম আয়</div>
                  <div className="text-2xl font-black text-amber-300 mt-1">₹14,800</div>
                  <div className="text-[11px] text-purple-200 font-semibold mt-0.5">₹10 / ফরম্যাট ফি</div>
                </div>

                <div className="bg-purple-900/60 border border-purple-700/60 p-4 rounded-2xl">
                  <div className="text-xs text-purple-300 font-bold">সার্ভার স্ট্যাটাস</div>
                  <div className="text-2xl font-black text-emerald-400 mt-1 flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping"></span>
                    100% Active
                  </div>
                  <div className="text-[11px] text-purple-200 font-semibold mt-0.5">WB Cloud Node: Kolkata</div>
                </div>
              </div>

              {/* Credit Notice Toast */}
              {creditNotice && (
                <div className="bg-emerald-500 text-slate-950 px-4 py-2.5 rounded-xl text-xs font-black flex items-center justify-between shadow-lg animate-in fade-in">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{creditNotice}</span>
                  </div>
                  <button onClick={() => setCreditNotice(null)} className="text-xs font-bold underline">ঠিক আছে</button>
                </div>
              )}

              {/* Shopkeeper / Cyber Cafe Directory Table for Admin */}
              <div className="bg-slate-900/90 border border-purple-700/60 rounded-2xl p-5 shadow-xl">
                <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                  <div>
                    <h4 className="text-base font-black text-white flex items-center gap-2">
                      <Store className="w-4 h-4 text-purple-400" />
                      দোকানদার ও সাইবার ক্যাফে ব্যালেন্স ডিরেক্টরি (Master Wallet Manager)
                    </h4>
                    <p className="text-xs text-purple-300 mt-0.5">
                      এখান থেকে আপনি যেকোনো সাইবার ক্যাফে বা দোকানদারের ব্যালেন্স দেখতে পারবেন এবং সরাসরি ব্যালেন্স অ্যাড করতে পারবেন।
                    </p>
                  </div>

                  {/* Search Bar */}
                  <div className="relative w-full sm:w-64">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="নাম, ফোন বা জেলা দিয়ে খুঁজুন..."
                      className="w-full pl-9 pr-3 py-2 bg-slate-800 border border-purple-600/40 rounded-xl text-xs font-medium text-white placeholder-slate-400 focus:outline-none focus:border-purple-400"
                    />
                  </div>
                </div>

                {/* Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-purple-300 font-bold bg-slate-950/60">
                        <th className="py-2.5 px-3">দোকান / সেন্টারের নাম</th>
                        <th className="py-2.5 px-3">অপারেটর</th>
                        <th className="py-2.5 px-3">ধরন</th>
                        <th className="py-2.5 px-3">ফোন নম্বর</th>
                        <th className="py-2.5 px-3">জেলা</th>
                        <th className="py-2.5 px-3">ব্যালেন্স</th>
                        <th className="py-2.5 px-3 text-right">অ্যাডমিন অ্যাকশন</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {filteredShops.map((shop) => (
                        <tr key={shop.id} className="hover:bg-slate-800/50 transition">
                          <td className="py-2.5 px-3 font-bold text-white flex items-center gap-1.5">
                            <Store className="w-3.5 h-3.5 text-amber-400" />
                            {shop.name}
                          </td>
                          <td className="py-2.5 px-3 text-slate-300">{shop.owner}</td>
                          <td className="py-2.5 px-3">
                            <span className="bg-purple-900/60 text-purple-300 border border-purple-700/50 px-2 py-0.5 rounded-full text-[10px] font-bold">
                              {shop.type}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 font-mono text-slate-300">{shop.phone}</td>
                          <td className="py-2.5 px-3 text-slate-300">{shop.district}</td>
                          <td className="py-2.5 px-3 font-black text-amber-300">₹{shop.balance}</td>
                          <td className="py-2.5 px-3 text-right space-x-1.5">
                            <button
                              onClick={() => handleAdminCreditBalance(shop.id, 100)}
                              className="bg-emerald-600 hover:bg-emerald-500 text-white px-2.5 py-1 rounded-lg text-[11px] font-bold transition shadow-sm"
                            >
                              + ₹100
                            </button>
                            <button
                              onClick={() => handleAdminCreditBalance(shop.id, 500)}
                              className="bg-amber-500 hover:bg-amber-400 text-slate-950 px-2.5 py-1 rounded-lg text-[11px] font-black transition shadow-sm"
                            >
                              + ₹500
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. USERS / CYBER CAFE / SHOPKEEPER (দোকানদার) DEDICATED DASHBOARD HEADER */}
      {/* ========================================================================= */}
      <div className="bg-white border-2 border-amber-300 rounded-3xl p-5 sm:p-7 shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          
          {/* Left: Cyber Cafe Image (Prominent & Sharp) */}
          <div className="lg:col-span-6 relative rounded-2xl overflow-hidden border-2 border-amber-400/80 shadow-lg group">
            <img 
              src={cybercafeBg} 
              alt="Cyber Cafe Form Fillup Center" 
              className="w-full h-64 sm:h-72 object-cover object-center group-hover:scale-105 transition duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent"></div>
            
            {/* Top Verified Badge with Logo */}
            <div className="absolute top-3 left-3 flex items-center gap-2">
              <SahajBengalLogo size="sm" />
              <span className="inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 text-xs font-black px-3 py-1 rounded-full shadow-lg">
                <CheckCircle2 className="w-3.5 h-3.5" />
                SAHAJ BENGAL 2.0 VERIFIED
              </span>
            </div>

            {/* Bottom Floating Title on Image */}
            <div className="absolute bottom-3 left-3 right-3 text-white">
              <p className="text-xs text-amber-300 font-bold tracking-wide flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                {lang === 'bn' ? 'অফিসিয়াল ডিজিটাল ডাটা এন্ট্রি সেন্টার' : 'Official Digital Form Center'}
              </p>
              <h3 className="text-base sm:text-lg font-black text-white leading-snug drop-shadow-md">
                {lang === 'bn' ? 'নির্ভুল সরকারি ফর্ম ফিলাপ ও অটো-পিডিএফ জেনারেটর' : 'Accurate Govt Form Filling & Instant PDF Generation'}
              </h3>
            </div>
          </div>

          {/* Right: Portal Name with Logo, Balance & Quick Actions */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-4">
            <div>
              {/* Logo + Website Name (User Request 4) */}
              <div className="flex items-center gap-3 mb-2">
                <SahajBengalLogo size="md" />
                <div>
                  <h2 className="text-2xl sm:text-3xl font-black text-slate-950 tracking-tight leading-tight">
                    {lang === 'bn' ? 'সহজ বাংলা পোর্টাল ২.০' : 'SAHAJ BENGAL PORTAL 2.0'}
                  </h2>
                  <p className="text-xs font-extrabold text-amber-800">
                    {lang === 'bn' ? 'পশ্চিমবঙ্গ সরকারি ফর্ম ফিলাপ ও অটো-পিডিএফ জেনারেটর' : 'West Bengal Govt Form Filling & Instant PDF Portal'}
                  </p>
                </div>
              </div>

              {/* Shop / Operator & Wallet Highlight Card (User Request 3) */}
              <div className="bg-amber-50/80 border-2 border-amber-300 p-4 rounded-2xl shadow-sm my-3">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <div className="text-[11px] font-bold text-amber-900 flex items-center gap-1">
                      <Store className="w-3.5 h-3.5 text-amber-700" />
                      {cafeProfile.cafeName}
                    </div>
                    <div className="text-xs font-black text-slate-900 mt-0.5">
                      অপারেটর: {cafeProfile.operatorName} ({cafeProfile.location})
                    </div>
                  </div>

                  <div className="text-right flex items-center gap-2">
                    <div className="bg-white border-2 border-amber-300 px-3 py-1.5 rounded-xl shadow-sm">
                      <div className="text-[10px] font-bold text-slate-500">আপনার ব্যালেন্স</div>
                      <div className="text-base font-black text-slate-950">₹{cafeProfile.walletBalance}</div>
                    </div>
                    {onOpenWallet && (
                      <button
                        onClick={onOpenWallet}
                        className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-3 py-2 rounded-xl text-xs shadow-md transition active:scale-95"
                      >
                        + রিচার্জ
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <p className="text-xs leading-relaxed text-slate-700 font-medium">
                {lang === 'bn'
                  ? 'সাইবার ক্যাফে ও দোকানদারদের জন্য তৈরি। গ্রাহকের তথ্য দিয়ে দ্রুত ফর্ম ফিলাপ করুন এবং মূল পশ্চিমবঙ্গ সরকারি ৩-পেজ ফরম্যাটে হুবহু A4 সাইজে ডাউনলোড করুন। ডাউনলোড সম্পন্ন হওয়ামাত্র গ্রাহকের সমস্ত ডেটা স্বয়ংক্রিয়ভাবে ডিলিট হয়ে যায়।'
                  : 'Tailored for Cyber Cafes and Shopkeepers. Fast accurate data entry mapped onto official West Bengal government 3-page A4 forms.'}
              </p>
            </div>

            {/* Quick Launch Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                onClick={() => onOpenDataEntry(false)}
                className="flex-1 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black px-5 py-3 rounded-xl shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition active:scale-95 text-sm"
              >
                <FileCheck2 className="w-4 h-4" />
                <span>{lang === 'bn' ? 'ডাটা এন্ট্রি শুরু করুন' : 'Start Data Entry'}</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

              <button
                onClick={() => onOpenDataEntry(true)}
                className="font-black px-4 py-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-950 border-2 border-indigo-200 flex items-center justify-center gap-1.5 transition text-xs sm:text-sm shadow-sm"
              >
                <Zap className="w-4 h-4 text-indigo-600" />
                <span>{lang === 'bn' ? 'টেস্ট ডাটা' : 'Sample Data'}</span>
              </button>
            </div>

          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. ACTIVE SCHEME PROFESSIONAL HERO BOX */}
      {/* ========================================================================= */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping"></span>
            <h3 className="text-lg font-black text-slate-950">
              {lang === 'bn' ? 'বর্তমান সক্রিয় স্কিম (Active Scheme)' : 'Current Active Scheme'}
            </h3>
          </div>
          <span className="text-xs font-black px-3 py-1 rounded-full bg-amber-100 text-amber-950 border-2 border-amber-300">
            {lang === 'bn' ? '৩-পেজ অরিজিনাল A4 ফরম্যাট' : '3-Page Official A4 Format'}
          </span>
        </div>

        {/* Hero Card Container */}
        <div className="bg-white border-2 border-amber-300 rounded-3xl overflow-hidden shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left Scheme Visual Badge */}
            <div className="lg:col-span-5 relative bg-gradient-to-br from-amber-50 via-orange-50/60 to-amber-100/70 border-b lg:border-b-0 lg:border-r-2 border-amber-200 p-6 sm:p-8 flex flex-col justify-between overflow-hidden">
              
              {/* Top Badges */}
              <div className="relative z-10 flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-400 to-orange-400 text-slate-950 text-xs font-black px-3 py-1 rounded-full shadow-md">
                  <CheckCircle className="w-3.5 h-3.5" />
                  {activeScheme.badge}
                </span>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-white text-slate-800 border border-slate-300 shadow-sm">
                  {activeScheme.state}
                </span>
              </div>

              {/* Form Image / Icon Banner */}
              <div className="relative z-10 my-6">
                <div className="p-5 rounded-2xl bg-white border-2 border-amber-200 shadow-md">
                  <div className="flex items-center gap-3.5">
                    <div className="w-12 h-12 rounded-xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-800 shadow-inner font-bold">
                      <Layers className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-xs font-black uppercase tracking-wider text-amber-800">
                        {activeScheme.category}
                      </div>
                      <div className="text-base font-black text-slate-950 leading-tight">
                        {activeScheme.bengaliTitle}
                      </div>
                    </div>
                  </div>

                  {/* Highlights Checklist */}
                  <div className="mt-4 pt-3.5 border-t border-amber-200 space-y-2 text-xs text-slate-700">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-700 flex-shrink-0" />
                      <span>{lang === 'bn' ? 'সদস্য ১ থেকে ৬ ও অতিরিক্ত সদস্য সাপোর্ট' : 'Members 1 to 6 & Additional Members'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-700 flex-shrink-0" />
                      <span>{lang === 'bn' ? 'আধার, রেশন কার্ড, ভোটার ও প্যান নম্বর ফিল্ড' : 'Aadhar, Ration Card, EPIC & PAN fields'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Lock className="w-3.5 h-3.5 text-orange-600 flex-shrink-0" />
                      <span className="font-bold text-amber-950">
                        {lang === 'bn' ? 'সরকারি অফিসারের অংশ সম্পূর্ণ ফাঁকা থাকবে' : 'Official use section kept strictly blank'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Download fee tag */}
              <div className="relative z-10 flex items-center justify-between text-xs pt-3 border-t border-amber-200 text-slate-700">
                <span className="font-bold">{lang === 'bn' ? 'ডাউনলোড ফি:' : 'Download Fee:'}</span>
                <span className="font-black text-sm text-amber-950">₹{activeScheme.charge} / Download</span>
              </div>
            </div>

            {/* Right Form Description & Action Box */}
            <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between bg-white">
              <div>
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-wide mb-1 text-amber-800">
                  <Zap className="w-3.5 h-3.5 text-amber-600" />
                  {lang === 'bn' ? 'পশ্চিমবঙ্গ স্বাস্থ্য বীমা প্রকল্প' : 'West Bengal Health Insurance Scheme'}
                </div>

                <h4 className="text-xl sm:text-2xl font-black text-slate-950 tracking-tight">
                  {activeScheme.title}
                </h4>
                <p className="text-sm font-bold mt-1 text-slate-600">
                  {activeScheme.subtitle}
                </p>

                {/* Highlight box */}
                <div className="my-5 p-5 rounded-2xl bg-amber-50/90 border-2 border-amber-300 shadow-sm">
                  <div className="flex items-start gap-3.5">
                    <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center flex-shrink-0 mt-0.5 shadow-md font-bold">
                      <Sparkles className="w-5 h-5" />
                    </div>
                    <div>
                      <h5 className="font-black text-base sm:text-lg text-slate-950">
                        {activeScheme.description}
                      </h5>
                      <p className="text-xs mt-1.5 leading-relaxed font-semibold text-slate-700">
                        {lang === 'bn' 
                          ? 'গ্রাহক তথ্য পূরণ করুন এবং ১-ক্লিকে মূল ৩-পেজ সরকারি A4 পিডিএফ ফরম্যাটে ডাউনলোড করুন (১০ টাকা চার্জ)।'
                          : 'Fill customer beneficiary details and download the 100% exact official 3-page A4 PDF instantly (₹10 Charge).'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Features Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 my-4">
                  <div className="p-3.5 rounded-xl bg-slate-50 border-2 border-slate-200">
                    <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'মোট পৃষ্ঠা' : 'Pages'}</div>
                    <div className="text-sm font-black text-slate-950 mt-0.5">৩টি পৃষ্ঠা (A4 Size)</div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border-2 border-slate-200">
                    <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'সদস্য সীমা' : 'Members'}</div>
                    <div className="text-sm font-black text-slate-950 mt-0.5">৬ জন + পরিবার প্রধান</div>
                  </div>
                  <div className="p-3.5 rounded-xl bg-slate-50 border-2 border-slate-200">
                    <div className="text-[11px] text-slate-500 font-bold">{lang === 'bn' ? 'অফিসিয়াল ব্যবহার' : 'Official Area'}</div>
                    <div className="text-sm font-black text-amber-900 mt-0.5">{lang === 'bn' ? 'লকড / ফাঁকা থাকবে' : 'Kept Blank'}</div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-5 border-t-2 border-slate-100 flex flex-wrap items-center gap-3">
                {/* Primary Data Entry Button */}
                <button
                  onClick={() => onOpenDataEntry(false)}
                  className="flex-1 sm:flex-initial bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black px-6 py-3 rounded-xl shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition active:scale-95 text-sm sm:text-base"
                >
                  <FileCheck2 className="w-5 h-5" />
                  <span>{lang === 'bn' ? 'Data Entry করুন (₹10)' : 'Start Data Entry (₹10)'}</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>

                {/* Quick Sample Test Fill */}
                <button
                  onClick={() => onOpenDataEntry(true)}
                  className="font-bold px-4 py-3 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-950 border-2 border-amber-300 flex items-center justify-center gap-1.5 transition text-xs sm:text-sm shadow-sm"
                  title="Quick autofill with realistic sample test data"
                >
                  <Zap className="w-4 h-4 text-amber-600" />
                  <span>{lang === 'bn' ? 'স্যাম্পল টেস্ট ডাটা' : 'Test Sample Data'}</span>
                </button>

                {/* View Official Template */}
                <button
                  onClick={onOpenPreviewTemplate}
                  className="font-bold px-4 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border-2 border-slate-300 flex items-center justify-center gap-1.5 transition text-xs sm:text-sm shadow-sm"
                >
                  <Eye className="w-4 h-4 text-slate-600" />
                  <span>{lang === 'bn' ? 'অরিজিনাল ফরম্যাট দেখুন' : 'View Template'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. UPCOMING SCHEMES SECTION (User Request 3) */}
      {/* ========================================================================= */}
      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="text-lg font-black text-slate-950 flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-600" />
              {lang === 'bn' ? 'আসন্ন সরকারি স্কিম সমূহ (Upcoming Schemes)' : 'Upcoming Schemes'}
            </h3>
            <p className="text-xs font-bold text-slate-600 mt-0.5">
              {lang === 'bn'
                ? 'এই স্কিমগুলো পরবর্তীতে যুক্ত করা হবে অথবা AI স্ক্যানারের মাধ্যমে এখনই যেকোনো সরকারি ফর্ম আপলোড করে স্ক্যান করতে পারেন।'
                : 'Upcoming schemes will be available soon. You can also upload and scan any new form via AI instantly.'}
            </p>
          </div>

          <button
            onClick={onOpenScanner}
            className="self-start sm:self-auto inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black px-4 py-2 rounded-xl text-xs sm:text-sm shadow-md transition active:scale-95"
          >
            <UploadCloud className="w-4 h-4" />
            <span>{lang === 'bn' ? '+ নতুন ফর্ম আপলোড ও স্ক্যান করুন' : '+ Upload & Scan Any Form'}</span>
          </button>
        </div>

        {/* Upcoming Status Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Card 1 */}
          <div className="p-6 rounded-2xl bg-white border-2 border-slate-200 hover:border-amber-300 shadow-md transition flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-950 border border-amber-300">
                  {lang === 'bn' ? 'আসন্ন' : 'Upcoming'}
                </span>
                <span className="text-xs text-slate-400 font-mono">WB-GOVT</span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-amber-50 border-2 border-amber-200 flex items-center justify-center text-amber-700 mb-3">
                <Clock className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-black text-slate-950 tracking-wide">
                Khadya Sathi & Ration Services
              </h4>
              <p className="text-xs mt-1.5 leading-relaxed text-slate-600 font-medium">
                {lang === 'bn'
                  ? 'খাদ্য সাথী ও রেশন কার্ড সংক্রান্ত ডিজিটাল ফর্ম শীঘ্রই চালু হবে।'
                  : 'Ration card service digital forms will be activated soon.'}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
              <span className="font-bold">{lang === 'bn' ? 'স্ট্যাটাস: আসন্ন' : 'Status: Upcoming'}</span>
              <span className="text-[11px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-black">Coming Soon</span>
            </div>
          </div>

          {/* Card 2 */}
          <div className="p-6 rounded-2xl bg-white border-2 border-slate-200 hover:border-amber-300 shadow-md transition flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-950 border border-amber-300">
                  {lang === 'bn' ? 'আসন্ন' : 'Upcoming'}
                </span>
                <span className="text-xs text-slate-400 font-mono">GOVT-INDIA</span>
              </div>
              <div className="w-12 h-12 rounded-xl bg-amber-50 border-2 border-amber-200 flex items-center justify-center text-amber-700 mb-3">
                <Layers className="w-6 h-6" />
              </div>
              <h4 className="text-lg font-black text-slate-950 tracking-wide">
                Digital Seva Auto-Form
              </h4>
              <p className="text-xs mt-1.5 leading-relaxed text-slate-600 font-medium">
                {lang === 'bn'
                  ? 'নতুন ডিজিটাল সরকারি সেবা ফর্ম অটোমেশন প্রক্রিয়াধীন।'
                  : 'New digital government form automation under preparation.'}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-600">
              <span className="font-bold">{lang === 'bn' ? 'স্ট্যাটাস: আসন্ন' : 'Status: Upcoming'}</span>
              <span className="text-[11px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-black">Coming Soon</span>
            </div>
          </div>

          {/* Special Action Card: Upload & Auto-Scan */}
          <div 
            onClick={onOpenScanner}
            className="p-6 rounded-2xl border-2 border-dashed border-amber-400 bg-amber-50/60 hover:bg-amber-100/80 flex flex-col items-center justify-center text-center cursor-pointer transition group shadow-md"
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center group-hover:scale-110 transition mb-3 shadow-md font-bold">
              <UploadCloud className="w-6 h-6" />
            </div>
            <h4 className="font-black text-base text-slate-950 group-hover:text-amber-900 transition">
              {lang === 'bn' ? 'অন্য কোনো সরকারি ফর্ম যোগ করবেন?' : 'Add Another Govt Form?'}
            </h4>
            <p className="text-xs mt-1 max-w-[220px] leading-relaxed text-slate-700 font-medium">
              {lang === 'bn'
                ? 'যেকোনো পিডিএফ বা ছবি আপলোড করুন, AI স্বয়ংক্রিয়ভাবে স্ক্যান করে ডাটা এন্ট্রি টুল বানিয়ে দেবে।'
                : 'Upload any form PDF/Image. AI will scan and create an instant data entry tool.'}
            </p>
            <div className="mt-3.5 inline-flex items-center gap-1.5 text-xs font-black text-slate-950 bg-gradient-to-r from-amber-400 to-orange-400 px-3.5 py-1.5 rounded-full shadow-md">
              <Sparkles className="w-3.5 h-3.5" />
              {lang === 'bn' ? 'AI ফর্ম স্ক্যানার' : 'AI Form Scanner'}
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. ZERO DATA RETENTION PRIVACY GUARANTEE BANNER */}
      {/* ========================================================================= */}
      <div className="p-6 sm:p-8 rounded-3xl border-2 border-emerald-300 bg-emerald-50/80 shadow-lg relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-200 border border-emerald-300 flex items-center justify-center text-emerald-800 flex-shrink-0 shadow-inner">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-black px-3 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 mb-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                {lang === 'bn' ? '১০০% গ্রাহক গোপনীয়তা সুরক্ষা' : '100% Customer Privacy Guaranteed'}
              </div>
              <h3 className="text-base sm:text-lg font-black text-slate-950">
                {lang === 'bn' ? 'ফর্ম ডাউনলোডের সঙ্গে সঙ্গে সমস্ত গ্রাহক তথ্য স্বয়ংক্রিয়ভাবে ডিলেট হয়' : 'Instant Customer Data Wipe After Every Download'}
              </h3>
              <p className="text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed text-slate-700 font-medium">
                {lang === 'bn'
                  ? 'সাইবার ক্যাফে ও দোকানদারদের গ্রাহকদের আধার নম্বর, রেশন কার্ড নম্বর ও পরিবারের তথ্যের নিরাপত্তার জন্য এই পোর্টালে কোনো হিস্ট্রি বা ব্যক্তিগত ডেটা সংরক্ষিত রাখা হয় না। প্রতিটি পিডিএফ ডাউনলোডের সঙ্গে সঙ্গে ফর্মের ডেটা সম্পূর্ণ মুছে যায়।'
                  : 'To protect beneficiary privacy, this portal never stores records in history or local database. All customer data is instantly wiped from memory upon download.'}
              </p>
            </div>
          </div>

          <div className="flex-shrink-0">
            <button
              onClick={() => onOpenDataEntry(false)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-black px-5 py-2.5 rounded-xl shadow-md flex items-center gap-2 text-xs sm:text-sm transition active:scale-95"
            >
              <FileCheck2 className="w-4 h-4" />
              <span>{lang === 'bn' ? 'নতুন ফর্ম পূরণ করুন' : 'Fill New Form'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
