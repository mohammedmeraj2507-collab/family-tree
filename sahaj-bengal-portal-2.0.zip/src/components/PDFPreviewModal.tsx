import React, { useState, useEffect } from 'react';
import { 
  X, 
  Download, 
  Printer, 
  ChevronLeft, 
  ChevronRight, 
  Eye, 
  CheckCircle2, 
  Lock, 
  ShieldCheck, 
  FileText,
  Loader2
} from 'lucide-react';
import { SwasthyaBimaFormData, SchemeInfo } from '../types';
import { generateSwasthyaBimaPDF } from '../utils/pdfGenerator';

interface PDFPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  formData: SwasthyaBimaFormData;
  scheme: SchemeInfo;
  onDownload: () => void;
  lang: 'bn' | 'en';
}

export const PDFPreviewModal: React.FC<PDFPreviewModalProps> = ({
  isOpen,
  onClose,
  formData,
  scheme,
  onDownload,
  lang,
}) => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pdfBlobUrl, setPdfBlobUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;
    setIsGenerating(true);

    generateSwasthyaBimaPDF(formData)
      .then((pdfBytes) => {
        if (!isMounted) return;
        const blob = new Blob([pdfBytes], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        setPdfBlobUrl(url);
        setIsGenerating(false);
      })
      .catch((err) => {
        console.error('Error generating preview PDF:', err);
        setIsGenerating(false);
      });

    return () => {
      isMounted = false;
      if (pdfBlobUrl) {
        URL.revokeObjectURL(pdfBlobUrl);
      }
    };
  }, [isOpen, formData]);

  if (!isOpen) return null;

  const handlePrint = () => {
    if (!pdfBlobUrl) return;
    const printWindow = window.open(pdfBlobUrl, '_blank');
    if (printWindow) {
      printWindow.focus();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                  {lang === 'bn' ? 'অফিসিয়াল ৩-পেজ প্রিভিউ' : 'Official 3-Page PDF Preview'}
                </span>
                <span className="text-xs text-slate-400">| A4 Portrait (West Bengal)</span>
              </div>
              <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                {scheme.title}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={!pdfBlobUrl}
              className="inline-flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 px-3.5 py-2 rounded-xl text-xs font-semibold transition"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">{lang === 'bn' ? 'প্রিন্ট' : 'Print'}</span>
            </button>

            <button
              onClick={onDownload}
              className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md transition"
            >
              <Download className="w-4 h-4" />
              <span>{lang === 'bn' ? 'ডাউনলোড PDF (₹10)' : 'Download PDF (₹10)'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Page Switcher Sub-header */}
        <div className="px-6 py-2.5 bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-600 dark:text-slate-300">
              {lang === 'bn' ? 'পৃষ্ঠা নির্বাচন:' : 'Page Navigation:'}
            </span>
            <div className="flex items-center gap-1">
              {[1, 2, 3].map((pg) => (
                <button
                  key={pg}
                  onClick={() => setCurrentPage(pg)}
                  className={`px-3 py-1 rounded-lg font-bold transition ${
                    currentPage === pg
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  {lang === 'bn' ? `পৃষ্ঠা ${pg}` : `Page ${pg}`}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
            <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              {lang === 'bn' ? 'আসল সরকারি ছকের সাথে ১০০% মিল' : '100% Exact Official Template'}
            </span>
          </div>
        </div>

        {/* Modal Body / Visual Page Render */}
        <div className="flex-1 p-4 sm:p-6 overflow-y-auto bg-slate-200/60 dark:bg-slate-950 flex justify-center items-start min-h-[480px]">
          {isGenerating ? (
            <div className="flex flex-col items-center justify-center py-20 text-slate-500">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-500 mb-3" />
              <p className="font-medium text-sm">
                {lang === 'bn' ? 'পিডিএফ প্রস্তুত হচ্ছে...' : 'Rendering high-accuracy PDF...'}
              </p>
            </div>
          ) : (
            <div className="w-full max-w-3xl bg-white text-black p-8 sm:p-12 rounded-lg shadow-xl border border-slate-300 font-sans text-xs relative select-none">
              {/* PAGE 1 PREVIEW */}
              {currentPage === 1 && (
                <div className="space-y-6">
                  {/* Top Header */}
                  <div className="text-center space-y-1">
                    <h2 className="font-black text-lg tracking-wide text-black">
                      MUKHYAMANTRI SWASTHYA BIMA YOJANA
                    </h2>
                    <p className="font-bold text-sm text-black">
                      Form for New Enrollment — West Bengal
                    </p>
                    <div className="text-right font-bold text-xs pt-1">
                      DATE: <span className="font-mono">{formData.formDate}</span>
                    </div>
                  </div>

                  {/* Members 1, 2, 3 tables */}
                  {[1, 2, 3].map((mNum) => {
                    const mem = formData.members[mNum - 1];
                    return (
                      <div key={mNum} className="space-y-1">
                        <div className="font-bold text-xs text-black">
                          BASIC BENEFICIARY DETAILS (Member {mNum})
                        </div>
                        <div className="border border-black grid grid-cols-12 text-[11px] divide-y divide-black">
                          {/* Row 1 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Aadhar No</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold font-mono text-blue-900 bg-blue-50/20">{mem?.aadharNo || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Applicant Name</div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.applicantName || ''}</div>

                          {/* Row 2 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Ration Card No.</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold text-blue-900 bg-blue-50/20">{mem?.rationCardNo || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal leading-tight">
                            Category<br />
                            <span className="text-[9px]">(AAY/SPHH/PHH/RKSY-1/RKSY-2/GEN)</span>
                          </div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.category || ''}</div>

                          {/* Row 3 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Aadhar Linked Mobile</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold font-mono text-blue-900 bg-blue-50/20">{mem?.aadharLinkedMobile || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Gender (M/F/O)</div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.gender || ''}</div>

                          {/* Row 4 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Date of Birth</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold text-blue-900 bg-blue-50/20">{mem?.dob || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">PAN Number</div>
                          <div className="col-span-3 p-1.5 font-bold font-mono text-blue-900 bg-blue-50/20">{mem?.panNumber || ''}</div>

                          {/* Row 5 Electoral Header */}
                          <div className="col-span-12 p-1 font-bold text-[10px] bg-slate-100">ELECTORAL DETAILS</div>

                          {/* Row 6 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">EPIC Number</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold font-mono text-blue-900 bg-blue-50/20">{mem?.epicNumber || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">AC Number</div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.acNumber || ''}</div>

                          {/* Row 7 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">PART Number</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold text-blue-900 bg-blue-50/20">{mem?.partNumber || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Serial Number</div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.serialNumber || ''}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* PAGE 2 PREVIEW */}
              {currentPage === 2 && (
                <div className="space-y-6">
                  {/* Members 4, 5, 6 tables */}
                  {[4, 5, 6].map((mNum) => {
                    const mem = formData.members[mNum - 1];
                    return (
                      <div key={mNum} className="space-y-1">
                        <div className="font-bold text-xs text-black">
                          BASIC BENEFICIARY DETAILS (Member {mNum})
                        </div>
                        <div className="border border-black grid grid-cols-12 text-[11px] divide-y divide-black">
                          {/* Row 1 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Aadhar No</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold font-mono text-blue-900 bg-blue-50/20">{mem?.aadharNo || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Applicant Name</div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.applicantName || ''}</div>

                          {/* Row 2 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Ration Card No.</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold text-blue-900 bg-blue-50/20">{mem?.rationCardNo || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal leading-tight">
                            Category<br />
                            <span className="text-[9px]">(AAY/SPHH/PHH/RKSY-1/RKSY-2/GEN)</span>
                          </div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.category || ''}</div>

                          {/* Row 3 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Aadhar Linked Mobile</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold font-mono text-blue-900 bg-blue-50/20">{mem?.aadharLinkedMobile || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Gender (M/F/O)</div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.gender || ''}</div>

                          {/* Row 4 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Date of Birth</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold text-blue-900 bg-blue-50/20">{mem?.dob || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">PAN Number</div>
                          <div className="col-span-3 p-1.5 font-bold font-mono text-blue-900 bg-blue-50/20">{mem?.panNumber || ''}</div>

                          {/* Row 5 Electoral Header */}
                          <div className="col-span-12 p-1 font-bold text-[10px] bg-slate-100">ELECTORAL DETAILS</div>

                          {/* Row 6 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">EPIC Number</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold font-mono text-blue-900 bg-blue-50/20">{mem?.epicNumber || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">AC Number</div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.acNumber || ''}</div>

                          {/* Row 7 */}
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">PART Number</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-bold text-blue-900 bg-blue-50/20">{mem?.partNumber || ''}</div>
                          <div className="col-span-3 p-1.5 border-r border-black font-normal">Serial Number</div>
                          <div className="col-span-3 p-1.5 font-bold text-blue-900 bg-blue-50/20">{mem?.serialNumber || ''}</div>
                        </div>
                      </div>
                    );
                  })}

                  {/* Additional Member Note */}
                  <div className="pt-4 text-[10px]">
                    <span className="font-bold">BASIC BENEFICIARY DETAILS (Additional Member)</span>{' '}
                    <span className="italic">(*In case of additional members please fill up member details in a blank sheet duly signed and attach with this form)</span>
                  </div>
                </div>
              )}

              {/* PAGE 3 PREVIEW */}
              {currentPage === 3 && (
                <div className="space-y-8">
                  <div className="font-bold text-sm text-black">Family Details</div>

                  <div className="border border-black grid grid-cols-12 text-[11px] divide-y divide-black">
                    {/* Row 1 Address */}
                    <div className="col-span-4 p-2 border-r border-black font-normal leading-tight">
                      FULL ADDRESS (HOUSE NO.<br />/ STREET / VILLAGE / WARD)
                    </div>
                    <div className="col-span-8 p-2 font-bold text-blue-900 bg-blue-50/20">
                      {formData.familyDetails.fullAddress || ''}
                    </div>

                    {/* Row 2 District & Block */}
                    <div className="col-span-3 p-2 border-r border-black font-normal">DISTRICT</div>
                    <div className="col-span-3 p-2 border-r border-black font-bold text-blue-900 bg-blue-50/20">{formData.familyDetails.district || ''}</div>
                    <div className="col-span-3 p-2 border-r border-black font-normal">BLOCK/ULB</div>
                    <div className="col-span-3 p-2 font-bold text-blue-900 bg-blue-50/20">{formData.familyDetails.blockUlb || ''}</div>

                    {/* Row 3 GP & Head */}
                    <div className="col-span-3 p-2 border-r border-black font-normal">GRAM PANCHAYAT / WARD</div>
                    <div className="col-span-3 p-2 border-r border-black font-bold text-blue-900 bg-blue-50/20">{formData.familyDetails.gramPanchayatWard || ''}</div>
                    <div className="col-span-3 p-2 border-r border-black font-normal">FAMILY HEAD NAME</div>
                    <div className="col-span-3 p-2 font-bold text-blue-900 bg-blue-50/20">{formData.familyDetails.familyHeadName || ''}</div>

                    {/* Row 4 Total Members & SS URN */}
                    <div className="col-span-3 p-2 border-r border-black font-normal">TOTAL FAMILY MEMBERS</div>
                    <div className="col-span-3 p-2 border-r border-black font-bold text-blue-900 bg-blue-50/20">{formData.familyDetails.totalFamilyMembers || ''}</div>
                    <div className="col-span-3 p-2 border-r border-black font-normal">SS URN NO. (17-DIGIT)</div>
                    <div className="col-span-3 p-2 font-bold font-mono text-blue-900 bg-blue-50/20">{formData.familyDetails.ssUrnNo || ''}</div>

                    {/* Row 5 Beneficiary Contact & Signature */}
                    <div className="col-span-3 p-2 border-r border-black font-normal leading-tight">
                      NAME and CONTACT<br />NUMBER OF BENEFICIARY
                    </div>
                    <div className="col-span-3 p-2 border-r border-black font-bold text-blue-900 bg-blue-50/20">{formData.familyDetails.beneficiaryNameContact || ''}</div>
                    <div className="col-span-3 p-2 border-r border-black font-normal leading-tight">
                      SIGNATURE OF THE<br />BENEFICIARY
                    </div>
                    <div className="col-span-3 p-2 italic font-serif font-bold text-blue-900 bg-blue-50/20">{formData.familyDetails.beneficiarySignature || ''}</div>
                  </div>

                  {/* OFFICIAL USE ONLY SECTION (BLANK AS MANDATED) */}
                  <div className="pt-8 space-y-6">
                    <div className="font-bold text-xs text-black flex items-center justify-between">
                      <span>Receiving Authority Name, Designation, Contact Number:</span>
                      <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-semibold">
                        [ সরকারি অফিসারের জন্য ফাঁকা থাকবে ]
                      </span>
                    </div>

                    <div className="font-bold text-xs text-black pt-4 flex items-center justify-between">
                      <span>Receiving Authority Signature:</span>
                      <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-semibold">
                        [ স্বাক্ষরের জন্য ফাঁকা থাকবে ]
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-900">
          <div className="flex items-center gap-2">
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 disabled:opacity-40 hover:bg-slate-100 transition"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300">
              {currentPage} / 3
            </span>
            <button
              disabled={currentPage === 3}
              onClick={() => setCurrentPage((p) => Math.min(3, p + 1))}
              className="p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 disabled:opacity-40 hover:bg-slate-100 transition"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition"
            >
              {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
            </button>

            <button
              onClick={onDownload}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-xl text-xs sm:text-sm shadow-md flex items-center gap-2 transition active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>{lang === 'bn' ? '১-ক্লিকে ডাউনলোড করুন (₹10)' : 'Download PDF Now (₹10)'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
